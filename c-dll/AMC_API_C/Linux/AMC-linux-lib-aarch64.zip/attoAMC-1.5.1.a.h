/**
 * Copyright (C) 2020 attocube systems AG
 * Usage is up to a separate agreement
**/

/**
 * @file generatedAPI.h
 * @brief API for use with attocube devices
**/

#ifndef __GENERATEDAPI_H_AMC_1_5_1__
#define __GENERATEDAPI_H_AMC_1_5_1__

#ifndef ATTO_PREFIX
#define ATTO_PREFIX AMC_
#endif

#define ATTO_PREFIX_CONCAT(x,y) x ## y
#define ATTO_PREFIX_EVALUATOR(x,y) ATTO_PREFIX_CONCAT(x,y)
#define ATTO_FUNCTION(function_name) ATTO_PREFIX_EVALUATOR(ATTO_PREFIX, function_name)

#include <stdbool.h>
#include "attocubeJSONCall.h"
#ifdef __cplusplus
extern "C" {
#endif

/** @brief @AMC_test_clearLog
*  Resets the log
*   For debugging only.
*
*  @param deviceHandle     Handle of device
*  @param axis             Axis of the AMC
*  @param testname         Name of the test
*
*  @param error_code       Error code
*
*  @return Error code
*/
int ATTOCUBE_API __AMC_1_5_1_test_clearLog(int deviceHandle, int axis, const char* testname, int* error_code);

static inline int ATTO_FUNCTION(test_clearLog)(int deviceHandle, int axis, const char* testname, int* error_code) {
    return __AMC_1_5_1_test_clearLog(deviceHandle, axis, testname, error_code);
}


/** @brief @AMC_test_execute
*  Starts a test run
*           For debugging only.
*   
*           Error codes:
*               ERR_OK = 0
*               ERR_TEST_DOES_NOT_EXIST = -1
*               ERR_TEST_RUNNING = -2
*
*  @param deviceHandle     Handle of device
*  @param name             Name of the test, see getAllTest()
*  @param parameters       Parameters object as stringified JSON object, where "default" is the applied value
Example
        "{
            "axis": {
                "friendlyName": "Axis",
                "default": "0"
            },
            "mode": {
                "friendlyName": "Mode",
                "default": 0
            },
            "amplitude": {
                "friendlyName": "Amplitude (V)",
                "default": "45"
            },
            "frequency": {
                "friendlyName": "Frequency (Hz)",
                "default": "2000"
            },
            "cycles": {
                "friendlyName": "Cycles",
                "default": "3"
            },
            "random_range": {
                "friendlyName": "Random range",
                "default": 500000
            },
            "buffer": {
                "friendlyName": "Buffer",
                 "default": 2000
            },
            "sample_period": {
                "friendlyName": "Sample period (ms)",
                "default": "100"
            }
        }"
*
*  @param error_code       Error code
*
*  @return Error code
*/
int ATTOCUBE_API __AMC_1_5_1_test_execute(int deviceHandle, const char* name, const char* parameters, int* error_code);

static inline int ATTO_FUNCTION(test_execute)(int deviceHandle, const char* name, const char* parameters, int* error_code) {
    return __AMC_1_5_1_test_execute(deviceHandle, name, parameters, error_code);
}


/** @brief @AMC_test_getAllTests
*  Request all names of the registered tests
*           For debugging only.
*
*  @param deviceHandle     Handle of device
*  @param axis             
*
*  @param error_code       Error code
*  @param tests            Jsonified list with all automatic tests
Example
"[
    {
        "name": "Velocity Test",
        "parameters": {
            "axis": {
                "friendlyName": "Axis",
                "default": "0"
            },
            "mode": {
                "friendlyName": "Mode",
                "default": 0
            },
            "amplitude": {
                "friendlyName": "Amplitude (V)",
                "default": "45"
            },
            "frequency": {
                "friendlyName": "Frequency (Hz)",
                "default": "2000"
            },
            "cycles": {
                "friendlyName": "Cycles",
                "default": "3"
            },
            "random_range": {
                "friendlyName": "Random range",
                "default": 500000
            },
            "buffer": {
                "friendlyName": "Buffer",
                 "default": 2000
            },
            "sample_period": {
                "friendlyName": "Sample period (ms)",
                "default": "100"
            }
        },
         "version": "1.0.0",
         "stoppable": true
    }
]"

, "version": "1.0.0", "stoppable": true}]"
"stoppable" tells the user if this test can be aborted while running
*  @param size1            Maximum size of buffer tests
*  @param manualTests      Jsonified list with all manual tests
Example
"[{"name": "Capacity Test", "parameters": {"capacity": "Capacity (nF)"}, "version": "1.0.0"}]"
*  @param size2            Maximum size of buffer manualTests
*
*  @return Error code
*/
int ATTOCUBE_API __AMC_1_5_1_test_getAllTests(int deviceHandle, int axis, int* error_code, char* tests, int size1, char* manualTests, int size2);

static inline int ATTO_FUNCTION(test_getAllTests)(int deviceHandle, int axis, int* error_code, char* tests, int size1, char* manualTests, int size2) {
    return __AMC_1_5_1_test_getAllTests(deviceHandle, axis, error_code, tests, size1, manualTests, size2);
}


/** @brief @AMC_test_getLog
*  Gets the complete log
*   For debugging only.
*
*  @param deviceHandle     Handle of device
*  @param axis             Axis of the AMC
*
*  @param error_code       Error code
*  @param logs             Log string json-encoded ({testname: log-str})
*  @param size             Maximum size of buffer logs
*
*  @return Error code
*/
int ATTOCUBE_API __AMC_1_5_1_test_getLog(int deviceHandle, int axis, int* error_code, char* logs, int size);

static inline int ATTO_FUNCTION(test_getLog)(int deviceHandle, int axis, int* error_code, char* logs, int size) {
    return __AMC_1_5_1_test_getLog(deviceHandle, axis, error_code, logs, size);
}


/** @brief @AMC_test_getPositionerSN
*  Gets the serial number of the positioner connected to a given axis.
*   For debugging only.
*
*  @param deviceHandle     Handle of device
*  @param axis             
*
*  @param error_code       Error code
*  @param sn               Serial number of positioner
*  @param size             Maximum size of buffer sn
*
*  @return Error code
*/
int ATTOCUBE_API __AMC_1_5_1_test_getPositionerSN(int deviceHandle, int axis, int* error_code, char* sn, int size);

static inline int ATTO_FUNCTION(test_getPositionerSN)(int deviceHandle, int axis, int* error_code, char* sn, int size) {
    return __AMC_1_5_1_test_getPositionerSN(deviceHandle, axis, error_code, sn, size);
}


/** @brief @AMC_test_getReport
*  Get test report of last test run of specific test
*   name == "all": the test reports of all tests from last test run will be returned
*   For debugging only.
*
*  @param deviceHandle     Handle of device
*  @param axis             
*  @param name             Name of the test or "all"
*
*  @param error_code       Error code
*  @param report           Test report json-serialized
*  @param size             Maximum size of buffer report
*
*  @return Error code
*/
int ATTOCUBE_API __AMC_1_5_1_test_getReport(int deviceHandle, int axis, const char* name, int* error_code, char* report, int size);

static inline int ATTO_FUNCTION(test_getReport)(int deviceHandle, int axis, const char* name, int* error_code, char* report, int size) {
    return __AMC_1_5_1_test_getReport(deviceHandle, axis, name, error_code, report, size);
}


/** @brief @AMC_test_getStatus
*  Get the current execution status of the test sequencer
*   For debugging only.
*   
*   Status:
*       IDLE = 0
*       RUNNING = 1
*       FINISHED = 2
*       FINISHED_CYCLE = 3
*
*  @param deviceHandle     Handle of device
*  @param axis             
*
*  @param error_code       Error code
*  @param status           Status
*  @param test             Name of test which ran last
*  @param size             Maximum size of buffer test
*
*  @return Error code
*/
int ATTOCUBE_API __AMC_1_5_1_test_getStatus(int deviceHandle, int axis, int* error_code, int* status, char* test, int size);

static inline int ATTO_FUNCTION(test_getStatus)(int deviceHandle, int axis, int* error_code, int* status, char* test, int size) {
    return __AMC_1_5_1_test_getStatus(deviceHandle, axis, error_code, status, test, size);
}


/** @brief @AMC_test_getTestParameters
*  Get test parameters the current test on the given axis is executed with
*           For debugging only.
*
*  @param deviceHandle     Handle of device
*  @param axis             
*
*  @param error_code       Error code
*  @param parameters       Parameters object as stringified JSON object where "default" is the applied parameter
Example
"{"axis":{"friendlyName":"Axis","default":0},"min_amplitude":{"friendlyName":"Min. amplitude (V)","default":"45"},"max_amplitude":{"friendlyName":"Max. amplitude (V)","default":"60"},"start_position":{"friendlyName":"Start position","default":0}}"
*  @param size             Maximum size of buffer parameters
*
*  @return Error code
*/
int ATTOCUBE_API __AMC_1_5_1_test_getTestParameters(int deviceHandle, int axis, int* error_code, char* parameters, int size);

static inline int ATTO_FUNCTION(test_getTestParameters)(int deviceHandle, int axis, int* error_code, char* parameters, int size) {
    return __AMC_1_5_1_test_getTestParameters(deviceHandle, axis, error_code, parameters, size);
}


/** @brief @AMC_test_getTestplatz
*  Gets the number of the Testplatz where the AMC belongs to
*   For debugging only.
*
*  @param deviceHandle     Handle of device
*
*  @param error_code       Error code
*  @param testplatz        Number of Testplatz
*
*  @return Error code
*/
int ATTOCUBE_API __AMC_1_5_1_test_getTestplatz(int deviceHandle, int* error_code, int* testplatz);

static inline int ATTO_FUNCTION(test_getTestplatz)(int deviceHandle, int* error_code, int* testplatz) {
    return __AMC_1_5_1_test_getTestplatz(deviceHandle, error_code, testplatz);
}


/** @brief @AMC_test_setPositionerSN
*  Sets the serial number of the positioner connected to a given axis.
*   For debugging only.
*
*  @param deviceHandle     Handle of device
*  @param axis             Axis the positioner is connected to
*  @param sn               Serial number of the positioner
*
*  @param error_code       Error code
*
*  @return Error code
*/
int ATTOCUBE_API __AMC_1_5_1_test_setPositionerSN(int deviceHandle, int axis, const char* sn, int* error_code);

static inline int ATTO_FUNCTION(test_setPositionerSN)(int deviceHandle, int axis, const char* sn, int* error_code) {
    return __AMC_1_5_1_test_setPositionerSN(deviceHandle, axis, sn, error_code);
}


/** @brief @AMC_test_setTestplatz
*  Sets the number of the Testplatz where the AMC belongs to
*   For debugging only.
*
*  @param deviceHandle     Handle of device
*  @param testplatz        Number of Testplatz
*
*  @param error_code       Error code
*
*  @return Error code
*/
int ATTOCUBE_API __AMC_1_5_1_test_setTestplatz(int deviceHandle, int testplatz, int* error_code);

static inline int ATTO_FUNCTION(test_setTestplatz)(int deviceHandle, int testplatz, int* error_code) {
    return __AMC_1_5_1_test_setTestplatz(deviceHandle, testplatz, error_code);
}


/** @brief @AMC_test_stopCurrentTest
*  Stops the current test if it is stoppable
*   For debugging only.
*
*  @param deviceHandle     Handle of device
*  @param axis             
*
*  @param error_code       Error code
*
*  @return Error code
*/
int ATTOCUBE_API __AMC_1_5_1_test_stopCurrentTest(int deviceHandle, int axis, int* error_code);

static inline int ATTO_FUNCTION(test_stopCurrentTest)(int deviceHandle, int axis, int* error_code) {
    return __AMC_1_5_1_test_stopCurrentTest(deviceHandle, axis, error_code);
}


/** @brief @AMC_rotcomp_getControlTargetRanges
*  Checks if all three axis are in target range.
*
*  @param deviceHandle     Handle of device
*
*  @param in_target_range  true all three axes are in target range, false at least one axis is not in target range
*
*  @return true all three axes are in target range, false at least one axis is not in target range
*/
int ATTOCUBE_API __AMC_1_5_1_rotcomp_getControlTargetRanges(int deviceHandle, bool* in_target_range);

static inline int ATTO_FUNCTION(rotcomp_getControlTargetRanges)(int deviceHandle, bool* in_target_range) {
    return __AMC_1_5_1_rotcomp_getControlTargetRanges(deviceHandle, in_target_range);
}


/** @brief @AMC_rotcomp_getEnabled
*  Gets the enabled status of the rotation compensation
*
*  @param deviceHandle     Handle of device
*
*  @param enabled          true Rotation compensation is enabled, false Rotation compensation is disabled
*
*  @return true Rotation compensation is enabled, false Rotation compensation is disabled
*/
int ATTOCUBE_API __AMC_1_5_1_rotcomp_getEnabled(int deviceHandle, bool* enabled);

static inline int ATTO_FUNCTION(rotcomp_getEnabled)(int deviceHandle, bool* enabled) {
    return __AMC_1_5_1_rotcomp_getEnabled(deviceHandle, enabled);
}


/** @brief @AMC_rotcomp_getLUT
*  Gets the LUT file as JSON string
*
*  @param deviceHandle     Handle of device
*
*  @param lut              JSON string of the LUT file for the rotation compensation
*  @param size             Maximum size of buffer lut
*
*  @return JSON string of the LUT file for the rotation compensation
*/
int ATTOCUBE_API __AMC_1_5_1_rotcomp_getLUT(int deviceHandle, char* lut, int size);

static inline int ATTO_FUNCTION(rotcomp_getLUT)(int deviceHandle, char* lut, int size) {
    return __AMC_1_5_1_rotcomp_getLUT(deviceHandle, lut, size);
}


/** @brief @AMC_rotcomp_setEnabled
*  Enables and disables the rotation compensation
*
*  @param deviceHandle     Handle of device
*  @param enabled          true Rotation compensation is enabled, false Rotation compensation is disabled
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_rotcomp_setEnabled(int deviceHandle, bool enabled);

static inline int ATTO_FUNCTION(rotcomp_setEnabled)(int deviceHandle, bool enabled) {
    return __AMC_1_5_1_rotcomp_setEnabled(deviceHandle, enabled);
}


/** @brief @AMC_rotcomp_setLUT
*  Sets the LUT file from a JSON string
*
*  @param deviceHandle     Handle of device
*  @param lut_string       JSON string of the LUT file for the rotation compensation
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_rotcomp_setLUT(int deviceHandle, const char* lut_string);

static inline int ATTO_FUNCTION(rotcomp_setLUT)(int deviceHandle, const char* lut_string) {
    return __AMC_1_5_1_rotcomp_setLUT(deviceHandle, lut_string);
}


/** @brief @AMC_rotcomp_updateOffsets
*  Updates the start offsets of the axes
*
*  @param deviceHandle     Handle of device
*  @param offset_axis0     Offset of axis 1 in [nm]
*  @param offset_axis1     Offset of axis 2 in [nm]
*  @param offset_axis2     Offset of axis 3 in [nm]
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_rotcomp_updateOffsets(int deviceHandle, int offset_axis0, int offset_axis1, int offset_axis2);

static inline int ATTO_FUNCTION(rotcomp_updateOffsets)(int deviceHandle, int offset_axis0, int offset_axis1, int offset_axis2) {
    return __AMC_1_5_1_rotcomp_updateOffsets(deviceHandle, offset_axis0, offset_axis1, offset_axis2);
}


/** @brief @AMC_about_getInstalledPackages
*  Gets list of packages installed on the device.
*
*  @param deviceHandle     Handle of device
*
*  @param value_string     string comma separated list of packages
*  @param size             Maximum size of buffer value_string
*
*  @return string comma separated list of packages
*/
int ATTOCUBE_API __AMC_1_5_1_about_getInstalledPackages(int deviceHandle, char* value_string, int size);

static inline int ATTO_FUNCTION(about_getInstalledPackages)(int deviceHandle, char* value_string, int size) {
    return __AMC_1_5_1_about_getInstalledPackages(deviceHandle, value_string, size);
}


/** @brief @AMC_about_getPackageLicense
*  Gets the license for a specific package.
*
*  @param deviceHandle     Handle of device
*  @param pckg             package name string
*
*  @param value_string     string license for this package
*  @param size             Maximum size of buffer value_string
*
*  @return string license for this package
*/
int ATTOCUBE_API __AMC_1_5_1_about_getPackageLicense(int deviceHandle, const char* pckg, char* value_string, int size);

static inline int ATTO_FUNCTION(about_getPackageLicense)(int deviceHandle, const char* pckg, char* value_string, int size) {
    return __AMC_1_5_1_about_getPackageLicense(deviceHandle, pckg, value_string, size);
}


/** @brief @AMC_update_getSwUpdateProgress
*  Gets the progress of running update.
*
*  @param deviceHandle     Handle of device
*
*  @param value_progress   progress value in %
*
*  @return progress value in %
*/
int ATTOCUBE_API __AMC_1_5_1_update_getSwUpdateProgress(int deviceHandle, int* value_progress);

static inline int ATTO_FUNCTION(update_getSwUpdateProgress)(int deviceHandle, int* value_progress) {
    return __AMC_1_5_1_update_getSwUpdateProgress(deviceHandle, value_progress);
}


/** @brief @AMC_update_getLicenseUpdateProgress
*  Gets the progress of running license update.
*
*  @param deviceHandle     Handle of device
*
*  @param value_progress   progress value in %
*
*  @return progress value in %
*/
int ATTOCUBE_API __AMC_1_5_1_update_getLicenseUpdateProgress(int deviceHandle, int* value_progress);

static inline int ATTO_FUNCTION(update_getLicenseUpdateProgress)(int deviceHandle, int* value_progress) {
    return __AMC_1_5_1_update_getLicenseUpdateProgress(deviceHandle, value_progress);
}


/** @brief @AMC_update_softwareUpdateBase64
*  Executes the update with base 64 file uploaded. After completion, a manual reboot is necessary.
*
*  @param deviceHandle     Handle of device
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_update_softwareUpdateBase64(int deviceHandle);

static inline int ATTO_FUNCTION(update_softwareUpdateBase64)(int deviceHandle) {
    return __AMC_1_5_1_update_softwareUpdateBase64(deviceHandle);
}


/** @brief @AMC_update_uploadSoftwareImageBase64
*  Uploads new firmware image in format base 64.
*
*  @param deviceHandle     Handle of device
*  @param offset           offset of the data
*  @param b64Data          base64 data string
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_update_uploadSoftwareImageBase64(int deviceHandle, int offset, const char* b64Data);

static inline int ATTO_FUNCTION(update_uploadSoftwareImageBase64)(int deviceHandle, int offset, const char* b64Data) {
    return __AMC_1_5_1_update_uploadSoftwareImageBase64(deviceHandle, offset, b64Data);
}


/** @brief @AMC_update_uploadLicenseBase64
*  Uploads new license file in format base 64.
*
*  @param deviceHandle     Handle of device
*  @param offset           offset of the data
*  @param b64Data          base64 data string
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_update_uploadLicenseBase64(int deviceHandle, int offset, const char* b64Data);

static inline int ATTO_FUNCTION(update_uploadLicenseBase64)(int deviceHandle, int offset, const char* b64Data) {
    return __AMC_1_5_1_update_uploadLicenseBase64(deviceHandle, offset, b64Data);
}


/** @brief @AMC_update_licenseUpdateBase64
*  Executes the license update with base64 file uploaded. After execution, a manual reboot is necessary.
*
*  @param deviceHandle     Handle of device
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_update_licenseUpdateBase64(int deviceHandle);

static inline int ATTO_FUNCTION(update_licenseUpdateBase64)(int deviceHandle) {
    return __AMC_1_5_1_update_licenseUpdateBase64(deviceHandle);
}


/** @brief @AMC_network_getRealIpAddress
*  Gets the real IP address of the device set to the network interface (br0, eth1 or eth0).
*
*  @param deviceHandle     Handle of device
*
*  @param value_IP         IP IP address
*  @param size             Maximum size of buffer value_IP
*
*  @return IP IP address
*/
int ATTOCUBE_API __AMC_1_5_1_network_getRealIpAddress(int deviceHandle, char* value_IP, int size);

static inline int ATTO_FUNCTION(network_getRealIpAddress)(int deviceHandle, char* value_IP, int size) {
    return __AMC_1_5_1_network_getRealIpAddress(deviceHandle, value_IP, size);
}


/** @brief @AMC_network_getIpAddress
*  Gets the IP address of the device.
*
*  @param deviceHandle     Handle of device
*
*  @param value_IP         IP address as string
*  @param size             Maximum size of buffer value_IP
*
*  @return IP address as string
*/
int ATTOCUBE_API __AMC_1_5_1_network_getIpAddress(int deviceHandle, char* value_IP, int size);

static inline int ATTO_FUNCTION(network_getIpAddress)(int deviceHandle, char* value_IP, int size) {
    return __AMC_1_5_1_network_getIpAddress(deviceHandle, value_IP, size);
}


/** @brief @AMC_network_setIpAddress
*  Sets the IP address of the device.
*
*  @param deviceHandle     Handle of device
*  @param address          IP address as string
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_network_setIpAddress(int deviceHandle, const char* address);

static inline int ATTO_FUNCTION(network_setIpAddress)(int deviceHandle, const char* address) {
    return __AMC_1_5_1_network_setIpAddress(deviceHandle, address);
}


/** @brief @AMC_network_getSubnetMask
*  Gets the subnet mask of the device.
*
*  @param deviceHandle     Handle of device
*
*  @param value_netmask    netmask subnet mask as string
*  @param size             Maximum size of buffer value_netmask
*
*  @return netmask subnet mask as string
*/
int ATTOCUBE_API __AMC_1_5_1_network_getSubnetMask(int deviceHandle, char* value_netmask, int size);

static inline int ATTO_FUNCTION(network_getSubnetMask)(int deviceHandle, char* value_netmask, int size) {
    return __AMC_1_5_1_network_getSubnetMask(deviceHandle, value_netmask, size);
}


/** @brief @AMC_network_setSubnetMask
*  Sets the subnet mask of the device.
*
*  @param deviceHandle     Handle of device
*  @param netmask          subnet mask as string
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_network_setSubnetMask(int deviceHandle, const char* netmask);

static inline int ATTO_FUNCTION(network_setSubnetMask)(int deviceHandle, const char* netmask) {
    return __AMC_1_5_1_network_setSubnetMask(deviceHandle, netmask);
}


/** @brief @AMC_network_getDefaultGateway
*  Gets the default gateway of the device.
*
*  @param deviceHandle     Handle of device
*
*  @param value_gateway    gateway default gateway as string
*  @param size             Maximum size of buffer value_gateway
*
*  @return gateway default gateway as string
*/
int ATTOCUBE_API __AMC_1_5_1_network_getDefaultGateway(int deviceHandle, char* value_gateway, int size);

static inline int ATTO_FUNCTION(network_getDefaultGateway)(int deviceHandle, char* value_gateway, int size) {
    return __AMC_1_5_1_network_getDefaultGateway(deviceHandle, value_gateway, size);
}


/** @brief @AMC_network_setDefaultGateway
*  Sets the default gateway of the device.
*
*  @param deviceHandle     Handle of device
*  @param gateway          default gateway as string
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_network_setDefaultGateway(int deviceHandle, const char* gateway);

static inline int ATTO_FUNCTION(network_setDefaultGateway)(int deviceHandle, const char* gateway) {
    return __AMC_1_5_1_network_setDefaultGateway(deviceHandle, gateway);
}


/** @brief @AMC_network_getDnsResolver
*  Gets the DNS resolver.
*
*  @param deviceHandle     Handle of device
*  @param priority         priority of DNS resolver (0 = default; 1 = backup)
*
*  @param value_resolver   resolver IP address of DNS resolver
*  @param size             Maximum size of buffer value_resolver
*
*  @return resolver IP address of DNS resolver
*/
int ATTOCUBE_API __AMC_1_5_1_network_getDnsResolver(int deviceHandle, int priority, char* value_resolver, int size);

static inline int ATTO_FUNCTION(network_getDnsResolver)(int deviceHandle, int priority, char* value_resolver, int size) {
    return __AMC_1_5_1_network_getDnsResolver(deviceHandle, priority, value_resolver, size);
}


/** @brief @AMC_network_setDnsResolver
*  Sets the DNS resolver.
*
*  @param deviceHandle     Handle of device
*  @param priority         priority of DNS resolver (0 = default; 1 = backup)
*  @param resolver         IP address of DNS resolver
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_network_setDnsResolver(int deviceHandle, int priority, const char* resolver);

static inline int ATTO_FUNCTION(network_setDnsResolver)(int deviceHandle, int priority, const char* resolver) {
    return __AMC_1_5_1_network_setDnsResolver(deviceHandle, priority, resolver);
}


/** @brief @AMC_network_getProxyServer
*  Gets the proxy settings of the device.
*
*  @param deviceHandle     Handle of device
*
*  @param value_proxyServer proxyServer proxy server setting, empty for no proxy
*  @param size             Maximum size of buffer value_proxyServer
*
*  @return proxyServer proxy server setting, empty for no proxy
*/
int ATTOCUBE_API __AMC_1_5_1_network_getProxyServer(int deviceHandle, char* value_proxyServer, int size);

static inline int ATTO_FUNCTION(network_getProxyServer)(int deviceHandle, char* value_proxyServer, int size) {
    return __AMC_1_5_1_network_getProxyServer(deviceHandle, value_proxyServer, size);
}


/** @brief @AMC_network_setProxyServer
*  Sets the proxy server of the device.
*
*  @param deviceHandle     Handle of device
*  @param proxyServer      proxy server setting
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_network_setProxyServer(int deviceHandle, const char* proxyServer);

static inline int ATTO_FUNCTION(network_setProxyServer)(int deviceHandle, const char* proxyServer) {
    return __AMC_1_5_1_network_setProxyServer(deviceHandle, proxyServer);
}


/** @brief @AMC_network_getEnableDhcpServer
*  Gets the status of DHCP server.
*
*  @param deviceHandle     Handle of device
*
*  @param value_enabled    enabled true = enabled; false = disabled
*
*  @return enabled true = enabled; false = disabled
*/
int ATTOCUBE_API __AMC_1_5_1_network_getEnableDhcpServer(int deviceHandle, bool* value_enabled);

static inline int ATTO_FUNCTION(network_getEnableDhcpServer)(int deviceHandle, bool* value_enabled) {
    return __AMC_1_5_1_network_getEnableDhcpServer(deviceHandle, value_enabled);
}


/** @brief @AMC_network_setEnableDhcpServer
*  Enables or disables DHCP server.
*
*  @param deviceHandle     Handle of device
*  @param enable           true = enable; false = disable
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_network_setEnableDhcpServer(int deviceHandle, bool enable);

static inline int ATTO_FUNCTION(network_setEnableDhcpServer)(int deviceHandle, bool enable) {
    return __AMC_1_5_1_network_setEnableDhcpServer(deviceHandle, enable);
}


/** @brief @AMC_network_getEnableDhcpClient
*  Gets the status of DHCP client.
*
*  @param deviceHandle     Handle of device
*
*  @param value_enabled    enabled true = enabled; false = disabled
*
*  @return enabled true = enabled; false = disabled
*/
int ATTOCUBE_API __AMC_1_5_1_network_getEnableDhcpClient(int deviceHandle, bool* value_enabled);

static inline int ATTO_FUNCTION(network_getEnableDhcpClient)(int deviceHandle, bool* value_enabled) {
    return __AMC_1_5_1_network_getEnableDhcpClient(deviceHandle, value_enabled);
}


/** @brief @AMC_network_setEnableDhcpClient
*  Enables or disables DHCP client.
*
*  @param deviceHandle     Handle of device
*  @param enable           true = enable; false = disable
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_network_setEnableDhcpClient(int deviceHandle, bool enable);

static inline int ATTO_FUNCTION(network_setEnableDhcpClient)(int deviceHandle, bool enable) {
    return __AMC_1_5_1_network_setEnableDhcpClient(deviceHandle, enable);
}


/** @brief @AMC_network_apply
*  Applies the temporary IP configuration and loads it.
*
*  @param deviceHandle     Handle of device
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_network_apply(int deviceHandle);

static inline int ATTO_FUNCTION(network_apply)(int deviceHandle) {
    return __AMC_1_5_1_network_apply(deviceHandle);
}


/** @brief @AMC_network_verify
*  Verifies if the temporary IP configuration is correct.
*
*  @param deviceHandle     Handle of device
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_network_verify(int deviceHandle);

static inline int ATTO_FUNCTION(network_verify)(int deviceHandle) {
    return __AMC_1_5_1_network_verify(deviceHandle);
}


/** @brief @AMC_network_discard
*  Discards the temporary IP configuration.
*
*  @param deviceHandle     Handle of device
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_network_discard(int deviceHandle);

static inline int ATTO_FUNCTION(network_discard)(int deviceHandle) {
    return __AMC_1_5_1_network_discard(deviceHandle);
}


/** @brief @AMC_network_getWifiPresent
*  Checks if a WiFi interface is present.
*
*  @param deviceHandle     Handle of device
*
*  @param value_present    present true if the interface is present, else false
*
*  @return present true if the interface is present, else false
*/
int ATTOCUBE_API __AMC_1_5_1_network_getWifiPresent(int deviceHandle, bool* value_present);

static inline int ATTO_FUNCTION(network_getWifiPresent)(int deviceHandle, bool* value_present) {
    return __AMC_1_5_1_network_getWifiPresent(deviceHandle, value_present);
}


/** @brief @AMC_network_setWifiMode
*  Changes the operation mode of the WiFi adapter.
*
*  @param deviceHandle     Handle of device
*  @param mode             0 = access point; 1 = WiFi client
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_network_setWifiMode(int deviceHandle, int mode);

static inline int ATTO_FUNCTION(network_setWifiMode)(int deviceHandle, int mode) {
    return __AMC_1_5_1_network_setWifiMode(deviceHandle, mode);
}


/** @brief @AMC_network_getWifiMode
*  Gets the operation mode of the WiFi adapter.
*
*  @param deviceHandle     Handle of device
*
*  @param value_mode       mode 0 = access point; 1 = WiFi client
*
*  @return mode 0 = access point; 1 = WiFi client
*/
int ATTOCUBE_API __AMC_1_5_1_network_getWifiMode(int deviceHandle, int* value_mode);

static inline int ATTO_FUNCTION(network_getWifiMode)(int deviceHandle, int* value_mode) {
    return __AMC_1_5_1_network_getWifiMode(deviceHandle, value_mode);
}


/** @brief @AMC_network_setWifiSSID
*  Changes the SSID of the network hosted (mode: access point) or connected to (mode: client).
*
*  @param deviceHandle     Handle of device
*  @param SSID             SSID string
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_network_setWifiSSID(int deviceHandle, const char* SSID);

static inline int ATTO_FUNCTION(network_setWifiSSID)(int deviceHandle, const char* SSID) {
    return __AMC_1_5_1_network_setWifiSSID(deviceHandle, SSID);
}


/** @brief @AMC_network_getWifiSSID
*  Gets the SSID of the network hosted (mode: access point) or connected to (mode: client).
*
*  @param deviceHandle     Handle of device
*
*  @param value_SSID       SSID SSID string
*  @param size             Maximum size of buffer value_SSID
*
*  @return SSID SSID string
*/
int ATTOCUBE_API __AMC_1_5_1_network_getWifiSSID(int deviceHandle, char* value_SSID, int size);

static inline int ATTO_FUNCTION(network_getWifiSSID)(int deviceHandle, char* value_SSID, int size) {
    return __AMC_1_5_1_network_getWifiSSID(deviceHandle, value_SSID, size);
}


/** @brief @AMC_network_setWifiPassphrase
*  Changes the passphrase of the network hosted (mode: access point) or connected to (mode: client).
*
*  @param deviceHandle     Handle of device
*  @param psk              pre-shared key
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_network_setWifiPassphrase(int deviceHandle, const char* psk);

static inline int ATTO_FUNCTION(network_setWifiPassphrase)(int deviceHandle, const char* psk) {
    return __AMC_1_5_1_network_setWifiPassphrase(deviceHandle, psk);
}


/** @brief @AMC_network_getWifiPassphrase
*  Gets the passphrase of the network hosted (mode: Access point) or connected to (mode: client).
*
*  @param deviceHandle     Handle of device
*
*  @param value_psk        psk pre-shared key
*  @param size             Maximum size of buffer value_psk
*
*  @return psk pre-shared key
*/
int ATTOCUBE_API __AMC_1_5_1_network_getWifiPassphrase(int deviceHandle, char* value_psk, int size);

static inline int ATTO_FUNCTION(network_getWifiPassphrase)(int deviceHandle, char* value_psk, int size) {
    return __AMC_1_5_1_network_getWifiPassphrase(deviceHandle, value_psk, size);
}


/** @brief @AMC_network_configureWifi
*  Changes the WiFi configuration and applies it.
*
*  @param deviceHandle     Handle of device
*  @param mode             0 = access point; 1 = WiFi client
*  @param SSID             SSID string
*  @param psk              pre-shared key
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_network_configureWifi(int deviceHandle, int mode, const char* SSID, const char* psk);

static inline int ATTO_FUNCTION(network_configureWifi)(int deviceHandle, int mode, const char* SSID, const char* psk) {
    return __AMC_1_5_1_network_configureWifi(deviceHandle, mode, SSID, psk);
}


/** @brief @AMC_setDeviceName
*  Sets custom name for the device.
*
*  @param deviceHandle     Handle of device
*  @param name             device name
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_system_service_setDeviceName(int deviceHandle, const char* name);

static inline int ATTO_FUNCTION(setDeviceName)(int deviceHandle, const char* name) {
    return __AMC_1_5_1_system_service_setDeviceName(deviceHandle, name);
}


/** @brief @AMC_getDeviceName
*  Gets the current device name.
*
*  @param deviceHandle     Handle of device
*
*  @param value_name       name current device name
*  @param size             Maximum size of buffer value_name
*
*  @return name current device name
*/
int ATTOCUBE_API __AMC_1_5_1_system_service_getDeviceName(int deviceHandle, char* value_name, int size);

static inline int ATTO_FUNCTION(getDeviceName)(int deviceHandle, char* value_name, int size) {
    return __AMC_1_5_1_system_service_getDeviceName(deviceHandle, value_name, size);
}


/** @brief @AMC_rebootSystem
*  Reboots the device.
*
*  @param deviceHandle     Handle of device
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_system_service_rebootSystem(int deviceHandle);

static inline int ATTO_FUNCTION(rebootSystem)(int deviceHandle) {
    return __AMC_1_5_1_system_service_rebootSystem(deviceHandle);
}


/** @brief @AMC_factoryReset
*  Turns on the factory reset flag. To perform the factory reset, a reboot is necessary afterwards. All settings will be set to default, and the device will be configured as DHCP server.
*
*  @param deviceHandle     Handle of device
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_system_service_factoryReset(int deviceHandle);

static inline int ATTO_FUNCTION(factoryReset)(int deviceHandle) {
    return __AMC_1_5_1_system_service_factoryReset(deviceHandle);
}


/** @brief @AMC_softReset
*  Performs a soft reset (factory reset without deleting the network settings). Please reboot the device directly afterwards.
*
*  @param deviceHandle     Handle of device
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_system_service_softReset(int deviceHandle);

static inline int ATTO_FUNCTION(softReset)(int deviceHandle) {
    return __AMC_1_5_1_system_service_softReset(deviceHandle);
}


/** @brief @AMC_errorNumberToString
*  Gets a description of an error code.
*
*  @param deviceHandle     Handle of device
*  @param language         integer: Language code 0 for the error name, 1 for a more user-friendly error message
*  @param errNbr           error code to translate
*
*  @param value_message    message error description
*  @param size             Maximum size of buffer value_message
*
*  @return message error description
*/
int ATTOCUBE_API __AMC_1_5_1_system_service_errorNumberToString(int deviceHandle, int language, int errNbr, char* value_message, int size);

static inline int ATTO_FUNCTION(errorNumberToString)(int deviceHandle, int language, int errNbr, char* value_message, int size) {
    return __AMC_1_5_1_system_service_errorNumberToString(deviceHandle, language, errNbr, value_message, size);
}


/** @brief @AMC_errorNumberToRecommendation
*  Gets a recommendation for the error code.
*
*  @param deviceHandle     Handle of device
*  @param language         integer: Language code
*  @param errNbr           error code to translate
*
*  @param value_string     string: error recommendation (currently returning an int = 0 until we have recommendations)
*  @param size             Maximum size of buffer value_string
*
*  @return string: error recommendation (currently returning an int = 0 until we have recommendations)
*/
int ATTOCUBE_API __AMC_1_5_1_system_service_errorNumberToRecommendation(int deviceHandle, int language, int errNbr, char* value_string, int size);

static inline int ATTO_FUNCTION(errorNumberToRecommendation)(int deviceHandle, int language, int errNbr, char* value_string, int size) {
    return __AMC_1_5_1_system_service_errorNumberToRecommendation(deviceHandle, language, errNbr, value_string, size);
}


/** @brief @AMC_getFirmwareVersion
*  Gets the firmware version of the device.
*
*  @param deviceHandle     Handle of device
*
*  @param value_FWversion  FWversion firmware version
*  @param size             Maximum size of buffer value_FWversion
*
*  @return FWversion firmware version
*/
int ATTOCUBE_API __AMC_1_5_1_system_service_getFirmwareVersion(int deviceHandle, char* value_FWversion, int size);

static inline int ATTO_FUNCTION(getFirmwareVersion)(int deviceHandle, char* value_FWversion, int size) {
    return __AMC_1_5_1_system_service_getFirmwareVersion(deviceHandle, value_FWversion, size);
}


/** @brief @AMC_getHardwareInfo
*  Retrieves the hardware information of the device.
*
*  @param deviceHandle     Handle of device
*
*  @param hardware_info_string hardware_info_string
*  @param size             Maximum size of buffer hardware_info_string
*
*  @return hardware_info_string
*/
int ATTOCUBE_API __AMC_1_5_1_system_service_getHardwareInfo(int deviceHandle, char* hardware_info_string, int size);

static inline int ATTO_FUNCTION(getHardwareInfo)(int deviceHandle, char* hardware_info_string, int size) {
    return __AMC_1_5_1_system_service_getHardwareInfo(deviceHandle, hardware_info_string, size);
}


/** @brief @AMC_getHostname
*  Returns the device hostname.
*
*  @param deviceHandle     Handle of device
*
*  @param value_name       name hostname
*  @param size             Maximum size of buffer value_name
*
*  @return name hostname
*/
int ATTOCUBE_API __AMC_1_5_1_system_service_getHostname(int deviceHandle, char* value_name, int size);

static inline int ATTO_FUNCTION(getHostname)(int deviceHandle, char* value_name, int size) {
    return __AMC_1_5_1_system_service_getHostname(deviceHandle, value_name, size);
}


/** @brief @AMC_getMacAddress
*  Gets the mac address of the device.
*
*  @param deviceHandle     Handle of device
*
*  @param value_mac        mac mac address
*  @param size             Maximum size of buffer value_mac
*
*  @return mac mac address
*/
int ATTOCUBE_API __AMC_1_5_1_system_service_getMacAddress(int deviceHandle, char* value_mac, int size);

static inline int ATTO_FUNCTION(getMacAddress)(int deviceHandle, char* value_mac, int size) {
    return __AMC_1_5_1_system_service_getMacAddress(deviceHandle, value_mac, size);
}


/** @brief @AMC_getSerialNumber
*  Gets the serial number of the device.
*
*  @param deviceHandle     Handle of device
*
*  @param value_SN         SN serial number
*  @param size             Maximum size of buffer value_SN
*
*  @return SN serial number
*/
int ATTOCUBE_API __AMC_1_5_1_system_service_getSerialNumber(int deviceHandle, char* value_SN, int size);

static inline int ATTO_FUNCTION(getSerialNumber)(int deviceHandle, char* value_SN, int size) {
    return __AMC_1_5_1_system_service_getSerialNumber(deviceHandle, value_SN, size);
}


/** @brief @AMC_getFluxCode
*  Gets the flux code of the system.
*
*  @param deviceHandle     Handle of device
*
*  @param value_code       code flux code
*  @param size             Maximum size of buffer value_code
*
*  @return code flux code
*/
int ATTOCUBE_API __AMC_1_5_1_system_service_getFluxCode(int deviceHandle, char* value_code, int size);

static inline int ATTO_FUNCTION(getFluxCode)(int deviceHandle, char* value_code, int size) {
    return __AMC_1_5_1_system_service_getFluxCode(deviceHandle, value_code, size);
}


/** @brief @AMC_updateTimeFromInternet
*  Updates system time by querying attocube.com.
*
*  @param deviceHandle     Handle of device
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_system_service_updateTimeFromInternet(int deviceHandle);

static inline int ATTO_FUNCTION(updateTimeFromInternet)(int deviceHandle) {
    return __AMC_1_5_1_system_service_updateTimeFromInternet(deviceHandle);
}


/** @brief @AMC_setTime
*  Sets system time manually.
*
*  @param deviceHandle     Handle of device
*  @param day              value from 1 to 31
*  @param month            value from 1 to 12
*  @param year             value (e.g. 2021)
*  @param hour             value from 0 to 23
*  @param minute           value from 0 to 59
*  @param second           value from 0 to 59
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_system_service_setTime(int deviceHandle, int day, int month, int year, int hour, int minute, int second);

static inline int ATTO_FUNCTION(setTime)(int deviceHandle, int day, int month, int year, int hour, int minute, int second) {
    return __AMC_1_5_1_system_service_setTime(deviceHandle, day, month, year, hour, minute, second);
}


/** @brief @AMC_description_checkChassisNbr
*  Get Chassis and Slot Number, only works when AMC is within a Rack
*
*  @param deviceHandle     Handle of device
*
*  @param slotNbr          slotNbr
*  @param chassisNbr       chassisNbr
*
*  @return slotNbr
*/
int ATTOCUBE_API __AMC_1_5_1_description_checkChassisNbr(int deviceHandle, int* slotNbr, int* chassisNbr);

static inline int ATTO_FUNCTION(description_checkChassisNbr)(int deviceHandle, int* slotNbr, int* chassisNbr) {
    return __AMC_1_5_1_description_checkChassisNbr(deviceHandle, slotNbr, chassisNbr);
}


/** @brief @AMC_control_setActorParametersJson
*  This function can be used to change several actor parameters with one call. All key-value-pairs in the second argument will be set to the given value.
 The other parameters remain unchanged. This function can not be used to load a different positioner-type and all its related parameters.
 Please use setActorParametersByName to do that.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param json_dict        dict with override params
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_control_setActorParametersJson(int deviceHandle, int axis, const char* json_dict);

static inline int ATTO_FUNCTION(control_setActorParametersJson)(int deviceHandle, int axis, const char* json_dict) {
    return __AMC_1_5_1_control_setActorParametersJson(deviceHandle, axis, json_dict);
}


/** @brief @AMC_control_getActorParametersJson
*  This function reads the current values of the given set of actor-parameters and retuns them as key-value-pairs in a json-string
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param param_list       comma separated list of parameters to be read out
*
*  @param value_parameters parameters json_dict of requested parameters
*  @param size             Maximum size of buffer value_parameters
*
*  @return parameters json_dict of requested parameters
*/
int ATTOCUBE_API __AMC_1_5_1_control_getActorParametersJson(int deviceHandle, int axis, const char* param_list, char* value_parameters, int size);

static inline int ATTO_FUNCTION(control_getActorParametersJson)(int deviceHandle, int axis, const char* param_list, char* value_parameters, int size) {
    return __AMC_1_5_1_control_getActorParametersJson(deviceHandle, axis, param_list, value_parameters, size);
}


/** @brief @AMC_description_getPositionersList
*  This function reads the actor names that can be connected to the device.
*
*  @param deviceHandle     Handle of device
*
*  @param PositionersList  PositionersList
*  @param size             Maximum size of buffer PositionersList
*
*  @return PositionersList
*/
int ATTOCUBE_API __AMC_1_5_1_description_getPositionersList(int deviceHandle, char* PositionersList, int size);

static inline int ATTO_FUNCTION(description_getPositionersList)(int deviceHandle, char* PositionersList, int size) {
    return __AMC_1_5_1_description_getPositionersList(deviceHandle, PositionersList, size);
}


/** @brief @AMC_description_getDeviceType
*  This function gets the device type based on its EEPROM configuration.
*
*  @param deviceHandle     Handle of device
*
*  @param value_devicetype devicetype Device name (AMC100, AMC150, AMC300) with attached feature ( AMC100/NUM, AMC100/NUM/PRO)
*  @param size             Maximum size of buffer value_devicetype
*
*  @return devicetype Device name (AMC100, AMC150, AMC300) with attached feature ( AMC100/NUM, AMC100/NUM/PRO)
*/
int ATTOCUBE_API __AMC_1_5_1_description_getDeviceType(int deviceHandle, char* value_devicetype, int size);

static inline int ATTO_FUNCTION(description_getDeviceType)(int deviceHandle, char* value_devicetype, int size) {
    return __AMC_1_5_1_description_getDeviceType(deviceHandle, value_devicetype, size);
}


/** @brief @AMC_description_getFeaturesActivated
*  Get the activated features and return as a string
*
*  @param deviceHandle     Handle of device
*
*  @param value_features   features activated on device concatenated by comma e.g. Closed loop Operation, Pro, Wireless Controller, IO
*  @param size             Maximum size of buffer value_features
*
*  @return features activated on device concatenated by comma e.g. Closed loop Operation, Pro, Wireless Controller, IO
*/
int ATTOCUBE_API __AMC_1_5_1_description_getFeaturesActivated(int deviceHandle, char* value_features, int size);

static inline int ATTO_FUNCTION(description_getFeaturesActivated)(int deviceHandle, char* value_features, int size) {
    return __AMC_1_5_1_description_getFeaturesActivated(deviceHandle, value_features, size);
}


/** @brief @AMC_move_setSingleStep
*  This function triggers one step on the selected axis in desired direction.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param backward         Selects the desired direction. False triggers a forward step, true a backward step
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_move_setSingleStep(int deviceHandle, int axis, bool backward);

static inline int ATTO_FUNCTION(move_setSingleStep)(int deviceHandle, int axis, bool backward) {
    return __AMC_1_5_1_move_setSingleStep(deviceHandle, axis, backward);
}


/** @brief @AMC_move_setNSteps
*  This function triggers n steps on the selected axis in desired direction. /PRO feature.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param backward         Selects the desired direction. False triggers a forward step, true a backward step
*  @param step             number of step
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_move_setNSteps(int deviceHandle, int axis, bool backward, int step);

static inline int ATTO_FUNCTION(move_setNSteps)(int deviceHandle, int axis, bool backward, int step) {
    return __AMC_1_5_1_move_setNSteps(deviceHandle, axis, backward, step);
}


/** @brief @AMC_move_writeNSteps
*  Sets the number of steps to perform on stepwise movement. /PRO feature.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param step             number of step
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_move_writeNSteps(int deviceHandle, int axis, int step);

static inline int ATTO_FUNCTION(move_writeNSteps)(int deviceHandle, int axis, int step) {
    return __AMC_1_5_1_move_writeNSteps(deviceHandle, axis, step);
}


/** @brief @AMC_move_performNSteps
*  Perform the OL command for N steps
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param backward         Selects the desired direction. False triggers a forward step, true a backward step
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_move_performNSteps(int deviceHandle, int axis, bool backward);

static inline int ATTO_FUNCTION(move_performNSteps)(int deviceHandle, int axis, bool backward) {
    return __AMC_1_5_1_move_performNSteps(deviceHandle, axis, backward);
}


/** @brief @AMC_move_getNSteps
*  This function gets the number of Steps in desired direction.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param nbrstep          nbrstep
*
*  @return nbrstep
*/
int ATTOCUBE_API __AMC_1_5_1_move_getNSteps(int deviceHandle, int axis, int* nbrstep);

static inline int ATTO_FUNCTION(move_getNSteps)(int deviceHandle, int axis, int* nbrstep) {
    return __AMC_1_5_1_move_getNSteps(deviceHandle, axis, nbrstep);
}


/** @brief @AMC_move_setControlContinuousFwd
*  This function sets a continuous movement on the selected axis in positive direction.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param enable           If enabled a present movement in the opposite direction is stopped. The parameter "false" stops all movement of the axis regardless its direction.
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_move_setControlContinuousFwd(int deviceHandle, int axis, bool enable);

static inline int ATTO_FUNCTION(move_setControlContinuousFwd)(int deviceHandle, int axis, bool enable) {
    return __AMC_1_5_1_move_setControlContinuousFwd(deviceHandle, axis, enable);
}


/** @brief @AMC_move_getControlContinuousFwd
*  This function gets the axis’ movement status in positive direction.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_enabled    enabled true if movement Fwd is active, false otherwise
*
*  @return enabled true if movement Fwd is active, false otherwise
*/
int ATTOCUBE_API __AMC_1_5_1_move_getControlContinuousFwd(int deviceHandle, int axis, bool* value_enabled);

static inline int ATTO_FUNCTION(move_getControlContinuousFwd)(int deviceHandle, int axis, bool* value_enabled) {
    return __AMC_1_5_1_move_getControlContinuousFwd(deviceHandle, axis, value_enabled);
}


/** @brief @AMC_move_setControlContinuousBkwd
*  This function sets a continuous movement on the selected axis in backward direction.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param enable           If enabled a present movement in the opposite direction is stopped. The parameter "false" stops all movement of the axis regardless its direction
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_move_setControlContinuousBkwd(int deviceHandle, int axis, bool enable);

static inline int ATTO_FUNCTION(move_setControlContinuousBkwd)(int deviceHandle, int axis, bool enable) {
    return __AMC_1_5_1_move_setControlContinuousBkwd(deviceHandle, axis, enable);
}


/** @brief @AMC_move_getControlContinuousBkwd
*  This function gets the axis’ movement status in backward direction.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_enabled    enabled true if movement backward is active , false otherwise
*
*  @return enabled true if movement backward is active , false otherwise
*/
int ATTOCUBE_API __AMC_1_5_1_move_getControlContinuousBkwd(int deviceHandle, int axis, bool* value_enabled);

static inline int ATTO_FUNCTION(move_getControlContinuousBkwd)(int deviceHandle, int axis, bool* value_enabled) {
    return __AMC_1_5_1_move_getControlContinuousBkwd(deviceHandle, axis, value_enabled);
}


/** @brief @AMC_move_getControlTargetPosition
*  This function gets the target position for the movement on the selected axis.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_position   position defined in nm for goniometer an rotator type actors it is µ°.
*
*  @return position defined in nm for goniometer an rotator type actors it is µ°.
*/
int ATTOCUBE_API __AMC_1_5_1_move_getControlTargetPosition(int deviceHandle, int axis, double* value_position);

static inline int ATTO_FUNCTION(move_getControlTargetPosition)(int deviceHandle, int axis, double* value_position) {
    return __AMC_1_5_1_move_getControlTargetPosition(deviceHandle, axis, value_position);
}


/** @brief @AMC_move_setControlTargetPosition
*  This function sets the target position for the movement on the selected axis.
 The maximum positon is +/-10'000'000'000 nm or uDeg, but please make sure not to enter a target position outside of your positioner's range.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param target           position: in nm for linear actuators for goniometers an rotators the unit is udeg.
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_move_setControlTargetPosition(int deviceHandle, int axis, double target);

static inline int ATTO_FUNCTION(move_setControlTargetPosition)(int deviceHandle, int axis, double target) {
    return __AMC_1_5_1_move_setControlTargetPosition(deviceHandle, axis, target);
}


/** @brief @AMC_move_moveReference
*  This function starts an approach to the reference position. A running motion command is aborted; closed loop moving is switched on. Requires a valid reference position.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_move_moveReference(int deviceHandle, int axis);

static inline int ATTO_FUNCTION(move_moveReference)(int deviceHandle, int axis) {
    return __AMC_1_5_1_move_moveReference(deviceHandle, axis);
}


/** @brief @AMC_move_getPosition
*  This function gets the current position of the positioner on the selected axis
 Note, that this function returns the position '0' in an AMC-IDS-Closedloop setup with IDS as sensor-source,
 if the IDS reports an error (e.g. beam-interrupt)
  The axis on the web application are indexed from 1 to 3
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_position   position defined in nm for goniometer an rotator type actors it is µ°.
*
*  @return position defined in nm for goniometer an rotator type actors it is µ°.
*/
int ATTOCUBE_API __AMC_1_5_1_move_getPosition(int deviceHandle, int axis, double* value_position);

static inline int ATTO_FUNCTION(move_getPosition)(int deviceHandle, int axis, double* value_position) {
    return __AMC_1_5_1_move_getPosition(deviceHandle, axis, value_position);
}


/** @brief @AMC_move_getPositionWithTime
*  This function gets the current position of the positioner and provides time-information to the position.
 The time information refers to the elapsed time since the last reboot of the device in microseconds.
 The axis on the web application are indexed from 1 to 3
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_Monotnoic_time_usec Monotnoic_time_usec: elapsed time in microseconds since last reboot of device
*  @param value_position   position defined in nm for goniometer an rotator type actors it is µ°.
*
*  @return Monotnoic_time_usec: elapsed time in microseconds since last reboot of device
*/
int ATTOCUBE_API __AMC_1_5_1_move_getPositionWithTime(int deviceHandle, int axis, double* value_Monotnoic_time_usec, double* value_position);

static inline int ATTO_FUNCTION(move_getPositionWithTime)(int deviceHandle, int axis, double* value_Monotnoic_time_usec, double* value_position) {
    return __AMC_1_5_1_move_getPositionWithTime(deviceHandle, axis, value_Monotnoic_time_usec, value_position);
}


/** @brief @AMC_move_getPositionWithTime_32Bit
*  This function gets the current position of the positioner and provides time-information to the position.
 The time information refers to the elapsed time since the last reboot of the device.
 This function is to be used if 64 bit numbers are not supported by your platform
 It returns two 32 bit numbers as time information instead of one number of 64 Bit (see description of return parameters).
 The axis on the web application are indexed from 1 to 3
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_Monotonic_time_sec Monotonic_time_sec: seconds passed since last reboot of device
*  @param value_Monotonic_time_nsec Monotonic_time_nsec: fractional seconds of Monotonic_time_sec
*  @param value_position   position defined in nm for goniometer an rotator type actors it is µ°.
*
*  @return Monotonic_time_sec: seconds passed since last reboot of device
*/
int ATTOCUBE_API __AMC_1_5_1_move_getPositionWithTime_32Bit(int deviceHandle, int axis, int* value_Monotonic_time_sec, int* value_Monotonic_time_nsec, double* value_position);

static inline int ATTO_FUNCTION(move_getPositionWithTime_32Bit)(int deviceHandle, int axis, int* value_Monotonic_time_sec, int* value_Monotonic_time_nsec, double* value_position) {
    return __AMC_1_5_1_move_getPositionWithTime_32Bit(deviceHandle, axis, value_Monotonic_time_sec, value_Monotonic_time_nsec, value_position);
}


/** @brief @AMC_move_getControlEotOutputDeactive
*  This function gets the output applied to the selected axis on the end of travel. /PRO feature.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_enabled    enabled If true, the output of the axis will be deactivated on positive EOT detection.
*
*  @return enabled If true, the output of the axis will be deactivated on positive EOT detection.
*/
int ATTOCUBE_API __AMC_1_5_1_move_getControlEotOutputDeactive(int deviceHandle, int axis, bool* value_enabled);

static inline int ATTO_FUNCTION(move_getControlEotOutputDeactive)(int deviceHandle, int axis, bool* value_enabled) {
    return __AMC_1_5_1_move_getControlEotOutputDeactive(deviceHandle, axis, value_enabled);
}


/** @brief @AMC_move_setControlEotOutputDeactive
*  This function sets the output applied to the selected axis on the end of travel.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param enable           if enabled, the output of the axis will be deactivated on positive EOT detection.
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_move_setControlEotOutputDeactive(int deviceHandle, int axis, bool enable);

static inline int ATTO_FUNCTION(move_setControlEotOutputDeactive)(int deviceHandle, int axis, bool enable) {
    return __AMC_1_5_1_move_setControlEotOutputDeactive(deviceHandle, axis, enable);
}


/** @brief @AMC_status_getStatusConnected
*  This function gets information about the connection status of the selected axis’ positioner.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_connected  connected If true, the actor is connected
*
*  @return connected If true, the actor is connected
*/
int ATTOCUBE_API __AMC_1_5_1_status_getStatusConnected(int deviceHandle, int axis, bool* value_connected);

static inline int ATTO_FUNCTION(status_getStatusConnected)(int deviceHandle, int axis, bool* value_connected) {
    return __AMC_1_5_1_status_getStatusConnected(deviceHandle, axis, value_connected);
}


/** @brief @AMC_status_getStatusReference
*  This function gets information about the status of the reference position.
 It can only be used in conjunction with NUM.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_valid      valid true = valid, false = not valid
*
*  @return valid true = valid, false = not valid
*/
int ATTOCUBE_API __AMC_1_5_1_status_getStatusReference(int deviceHandle, int axis, bool* value_valid);

static inline int ATTO_FUNCTION(status_getStatusReference)(int deviceHandle, int axis, bool* value_valid) {
    return __AMC_1_5_1_status_getStatusReference(deviceHandle, axis, value_valid);
}


/** @brief @AMC_status_getStatusMoving
*  This function gets information about the status of the stage output.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_status     status 0: Idle, i.e. within the noise range of the sensor, 1: Moving, i.e the actor is actively driven by the output stage either for closed-loop approach or continous/single stepping and the output is active.
  2 : Pending means the output stage is driving but the output is deactivated
*
*  @return status 0: Idle, i.e. within the noise range of the sensor, 1: Moving, i.e the actor is actively driven by the output stage either for closed-loop approach or continous/single stepping and the output is active.
  2 : Pending means the output stage is driving but the output is deactivated
*/
int ATTOCUBE_API __AMC_1_5_1_status_getStatusMoving(int deviceHandle, int axis, int* value_status);

static inline int ATTO_FUNCTION(status_getStatusMoving)(int deviceHandle, int axis, int* value_status) {
    return __AMC_1_5_1_status_getStatusMoving(deviceHandle, axis, value_status);
}


/** @brief @AMC_status_getStatusEotFwd
*  This function gets the status of the end of travel detection on the selected axis in forward direction.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_detected   detected true when EoT was detected
*
*  @return detected true when EoT was detected
*/
int ATTOCUBE_API __AMC_1_5_1_status_getStatusEotFwd(int deviceHandle, int axis, bool* value_detected);

static inline int ATTO_FUNCTION(status_getStatusEotFwd)(int deviceHandle, int axis, bool* value_detected) {
    return __AMC_1_5_1_status_getStatusEotFwd(deviceHandle, axis, value_detected);
}


/** @brief @AMC_status_getStatusEotBkwd
*  This function gets the status of the end of travel detection on the selected axis in backward direction.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_detected   detected true when EoT was detected
*
*  @return detected true when EoT was detected
*/
int ATTOCUBE_API __AMC_1_5_1_status_getStatusEotBkwd(int deviceHandle, int axis, bool* value_detected);

static inline int ATTO_FUNCTION(status_getStatusEotBkwd)(int deviceHandle, int axis, bool* value_detected) {
    return __AMC_1_5_1_status_getStatusEotBkwd(deviceHandle, axis, value_detected);
}


/** @brief @AMC_status_getStatusEot
*  Retrieves the status of the end of travel (EOT) detection in backward direction or in forward direction.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_detected   detected true when EoT in either direction was detected
*
*  @return detected true when EoT in either direction was detected
*/
int ATTOCUBE_API __AMC_1_5_1_status_getStatusEot(int deviceHandle, int axis, bool* value_detected);

static inline int ATTO_FUNCTION(status_getStatusEot)(int deviceHandle, int axis, bool* value_detected) {
    return __AMC_1_5_1_status_getStatusEot(deviceHandle, axis, value_detected);
}


/** @brief @AMC_status_getStatusTargetRange
*  This function gets information about whether the selected axis’ positioner is in target range or not.
 The detection only indicates whether the position is within the defined range. This status is updated periodically but currently not in real-time.
 If a fast detection is desired, please check the position in a loop
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_in_range   in_range true within the target range, false not within the target range
*
*  @return in_range true within the target range, false not within the target range
*/
int ATTOCUBE_API __AMC_1_5_1_status_getStatusTargetRange(int deviceHandle, int axis, bool* value_in_range);

static inline int ATTO_FUNCTION(status_getStatusTargetRange)(int deviceHandle, int axis, bool* value_in_range) {
    return __AMC_1_5_1_status_getStatusTargetRange(deviceHandle, axis, value_in_range);
}


/** @brief @AMC_status_getOlStatus
*  Get the Feedback status of the positioner
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_sensorstatus sensorstatus as integer 0: NUM Positioner connected 1: OL positioner connected  2: No positioner connected , 3: RES positione connected, 4: Positioner with IDS-CL connected
*
*  @return sensorstatus as integer 0: NUM Positioner connected 1: OL positioner connected  2: No positioner connected , 3: RES positione connected, 4: Positioner with IDS-CL connected
*/
int ATTOCUBE_API __AMC_1_5_1_status_getOlStatus(int deviceHandle, int axis, int* value_sensorstatus);

static inline int ATTO_FUNCTION(status_getOlStatus)(int deviceHandle, int axis, int* value_sensorstatus) {
    return __AMC_1_5_1_status_getOlStatus(deviceHandle, axis, value_sensorstatus);
}


/** @brief @AMC_control_setEoTParameters
*  Sets the two parameters, that define the behavior of the eot detection (how sensitive respectively how robust it works)
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2] (will be ignored, if minAvgStepSize equals nil)
*  @param minAvgStepSize_nm this correpsonds to the "eot_threshold"-parameter
*  @param numOfAvgedSteps  this defines the number of steps, over which the average step size is calculated
*
*  @param err              err
*
*  @return err
*/
int ATTOCUBE_API __AMC_1_5_1_control_setEoTParameters(int deviceHandle, int axis, int minAvgStepSize_nm, int numOfAvgedSteps, int* err);

static inline int ATTO_FUNCTION(control_setEoTParameters)(int deviceHandle, int axis, int minAvgStepSize_nm, int numOfAvgedSteps, int* err) {
    return __AMC_1_5_1_control_setEoTParameters(deviceHandle, axis, minAvgStepSize_nm, numOfAvgedSteps, err);
}


/** @brief @AMC_control_getEoTParameters
*  Gets the two parameters, that define the behavior of the eot detection (how sensitive respectively how robust it works)
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2] (will be ignored, if minAvgStepSize equals nil)
*
*  @param err              err
*  @param value_minAvgStepSize_nm minAvgStepSize_nm this correpsonds to the "eot_threshold"-parameter
*  @param value_numOfAvgedSteps numOfAvgedSteps this defines the number of steps, over which the average step size is calculated
*
*  @return err
*/
int ATTOCUBE_API __AMC_1_5_1_control_getEoTParameters(int deviceHandle, int axis, int* err, int* value_minAvgStepSize_nm, int* value_numOfAvgedSteps);

static inline int ATTO_FUNCTION(control_getEoTParameters)(int deviceHandle, int axis, int* err, int* value_minAvgStepSize_nm, int* value_numOfAvgedSteps) {
    return __AMC_1_5_1_control_getEoTParameters(deviceHandle, axis, err, value_minAvgStepSize_nm, value_numOfAvgedSteps);
}


/** @brief @AMC_status_getFullCombinedStatus
*  Get the full combined status of a positioner axis and returns the status as a string
 The following strings are possible:
 'positioner not connected': No positioner Connected
 'output not enabled': Positioner connected, but axis deactivated
 'ready': Axis active and idle, but ready to move
 'moving': Axis moving (closed loop or open loop)
 'in target range': Axis in closed loop and in target range
 'backward limit reached': Positioner below velocity threshold in backward direction
 'forward limit reached': Positioner below velocity in forward direction
 'grounded': Positioner grounded (only AMC300)
 'overtemperature': overtemperature detected (only with firmware 1_5_0 or higher)
 'output error': short-circuit detected; axis cannot be activated (only with firmware 1_5_0 or higher)
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param status_str       status_str
*  @param size             Maximum size of buffer status_str
*
*  @return status_str
*/
int ATTOCUBE_API __AMC_1_5_1_status_getFullCombinedStatus(int deviceHandle, int axis, char* status_str, int size);

static inline int ATTO_FUNCTION(status_getFullCombinedStatus)(int deviceHandle, int axis, char* status_str, int size) {
    return __AMC_1_5_1_status_getFullCombinedStatus(deviceHandle, axis, status_str, size);
}


/** @brief @AMC_control_getMotionControlThreshold
*  This function gets the threshold range within the closed-loop controlled movement stops to regulate.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_threshold  threshold in pm (nDeg for rotators and gonios)
*
*  @return threshold in pm (nDeg for rotators and gonios)
*/
int ATTOCUBE_API __AMC_1_5_1_control_getMotionControlThreshold(int deviceHandle, int axis, int* value_threshold);

static inline int ATTO_FUNCTION(control_getMotionControlThreshold)(int deviceHandle, int axis, int* value_threshold) {
    return __AMC_1_5_1_control_getMotionControlThreshold(deviceHandle, axis, value_threshold);
}


/** @brief @AMC_control_setMotionControlThreshold
*  This function sets the threshold range within the closed-loop controlled movement stops to regulate. Default depends on connected sensor type
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param threshold        in pm (nDeg for rotators and gonios)
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_control_setMotionControlThreshold(int deviceHandle, int axis, int threshold);

static inline int ATTO_FUNCTION(control_setMotionControlThreshold)(int deviceHandle, int axis, int threshold) {
    return __AMC_1_5_1_control_setMotionControlThreshold(deviceHandle, axis, threshold);
}


/** @brief @AMC_control_getCrosstalkThreshold
*  This function gets the threshold range and slip phase time which is used while moving another axis
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_range      range in pm
*  @param value_time       time after slip phase which is waited until the controller is acting again in microseconds
*
*  @return range in pm
*/
int ATTOCUBE_API __AMC_1_5_1_control_getCrosstalkThreshold(int deviceHandle, int axis, int* value_range, int* value_time);

static inline int ATTO_FUNCTION(control_getCrosstalkThreshold)(int deviceHandle, int axis, int* value_range, int* value_time) {
    return __AMC_1_5_1_control_getCrosstalkThreshold(deviceHandle, axis, value_range, value_time);
}


/** @brief @AMC_control_setCrosstalkThreshold
*  This function sets the threshold range to avoid axis-crosstalk and slip phase time which is used while moving another axis
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param threshold        [max:2000000000][pm]; has to be greater than the motion-control-threshold
*  @param slipphasetime    [min=0,max=65535][us] time after slip phase which is waited until the controller acts again
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_control_setCrosstalkThreshold(int deviceHandle, int axis, int threshold, int slipphasetime);

static inline int ATTO_FUNCTION(control_setCrosstalkThreshold)(int deviceHandle, int axis, int threshold, int slipphasetime) {
    return __AMC_1_5_1_control_setCrosstalkThreshold(deviceHandle, axis, threshold, slipphasetime);
}


/** @brief @AMC_control_getMoveDirInverted
*  This function gets whether the moving direction is inverted on a specific axis. This setting is only relevant for the external sensor. If internal sensor is selected, this parameter is ignored.
 Inversion means, that the AMC triggers bwd movement, if fwd-movement is commanded. This is supposed to straighten out upside down moving and measuring coordinate systems
 It is only available when the feature AMC/IDS closed loop has been activated.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_mvDirInverted mvDirInverted boolen
*
*  @return mvDirInverted boolen
*/
int ATTOCUBE_API __AMC_1_5_1_control_getMoveDirInverted(int deviceHandle, int axis, bool* value_mvDirInverted);

static inline int ATTO_FUNCTION(control_getMoveDirInverted)(int deviceHandle, int axis, bool* value_mvDirInverted) {
    return __AMC_1_5_1_control_getMoveDirInverted(deviceHandle, axis, value_mvDirInverted);
}


/** @brief @AMC_control_setMoveDirInverted
*  This function sets whether the moving direction shall be inverted on a specific axis. This parameter can only be set, if the external sensor is selected on this axis. Please refer to setAxesSensorSources for the external sensor setting. 
 Inversion means, that the AMC e.g. triggers bwd movement, if fwd-movement is commanded. This is supposed to straighten out upside down moving and measuring coordinate systems
 It is only available when the feature AMC/IDS closed loop has been activated.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param mvDirInverted    
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_control_setMoveDirInverted(int deviceHandle, int axis, bool mvDirInverted);

static inline int ATTO_FUNCTION(control_setMoveDirInverted)(int deviceHandle, int axis, bool mvDirInverted) {
    return __AMC_1_5_1_control_setMoveDirInverted(deviceHandle, axis, mvDirInverted);
}


/** @brief @AMC_control_getExternalSensor
*  This function gets whether the sensor source of closed loop is IDS
 It is only available when the feature AMC/IDS closed loop has been activated
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param enabled          enabled
*
*  @return enabled
*/
int ATTOCUBE_API __AMC_1_5_1_control_getExternalSensor(int deviceHandle, int axis, bool* enabled);

static inline int ATTO_FUNCTION(control_getExternalSensor)(int deviceHandle, int axis, bool* enabled) {
    return __AMC_1_5_1_control_getExternalSensor(deviceHandle, axis, enabled);
}


/** @brief @AMC_control_getAxesSensorSources
*  This function gets the current external sensor configuration for all axes
 It is only available when the feature AMC/IDS closed loop has been activated
 It returns an integer representing the configuration:
 0: intern,intern,intern
 1: extern,extern,extern
 2: extern,extern,intern
 3: intern,intern,extern
 4: inconsistent setting
 If this function returns '4', please run setAxesSensorSources with your desired configuration from above.
*
*  @param deviceHandle     Handle of device
*
*  @param value_extSensCfg extSensCfg [0: intern,intern,intern 1: extern,extern,extern 2: extern,extern,intern 3: intern,intern,extern 4:inconsitent]
*
*  @return extSensCfg [0: intern,intern,intern 1: extern,extern,extern 2: extern,extern,intern 3: intern,intern,extern 4:inconsitent]
*/
int ATTOCUBE_API __AMC_1_5_1_control_getAxesSensorSources(int deviceHandle, int* value_extSensCfg);

static inline int ATTO_FUNCTION(control_getAxesSensorSources)(int deviceHandle, int* value_extSensCfg) {
    return __AMC_1_5_1_control_getAxesSensorSources(deviceHandle, value_extSensCfg);
}


/** @brief @AMC_control_setAxesSensorSources
*  This function sets the sensor source according to the config passed to the function. An axis can be set to the IDS as sensor source ("external") or to the sensor of the positioner in use ("internal"; NUM or RES).
 Please note, that not all possible axis configurations are supported. Refer to the parameter description of extSensCfg for the supported configurations.
 It is only available when the feature AMC/IDS closed loop has been activated
*
*  @param deviceHandle     Handle of device
*  @param extSensCfg       [0: intern,intern,intern 1: extern,extern,extern 2: extern,extern,intern 3: intern,intern,extern]
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_control_setAxesSensorSources(int deviceHandle, int extSensCfg);

static inline int ATTO_FUNCTION(control_setAxesSensorSources)(int deviceHandle, int extSensCfg) {
    return __AMC_1_5_1_control_setAxesSensorSources(deviceHandle, extSensCfg);
}


/** @brief @AMC_control_getControlOutput
*  This function gets the activiation status of the axis.
 If active, move commands are accepted.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_enabled    enabled power status (true = enabled,false = disabled)
*
*  @return enabled power status (true = enabled,false = disabled)
*/
int ATTOCUBE_API __AMC_1_5_1_control_getControlOutput(int deviceHandle, int axis, bool* value_enabled);

static inline int ATTO_FUNCTION(control_getControlOutput)(int deviceHandle, int axis, bool* value_enabled) {
    return __AMC_1_5_1_control_getControlOutput(deviceHandle, axis, value_enabled);
}


/** @brief @AMC_control_setControlOutput
*  This function sets the activiation status of the axis.
Please make sure, a positioner is connected correctly to the corresponding axis before enabling an axis.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param enable           true: enable drives, false: disable drives
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_control_setControlOutput(int deviceHandle, int axis, bool enable);

static inline int ATTO_FUNCTION(control_setControlOutput)(int deviceHandle, int axis, bool enable) {
    return __AMC_1_5_1_control_setControlOutput(deviceHandle, axis, enable);
}


/** @brief @AMC_control_getOutputHealthStatus
*  This function gets the short circuit status of the selected axis
 Possible error codes for the axisHealthStatus are
 "73": "HW_SHORT_DETECTED - Unspecific short circuit detected on the drive pins. Axis disabled"
 "83": "HW_SCP_DETECTED - Short circuit detected. Axis is disabled and locked."
 "84": "HW_SCP_UNCONNECTED - Short circuit detected while no positioner connected. Axis is disabled and locked."
 "85": "HW_DC_CURRENT_TOO_HIGH - DC current too high during axis activation. Axis is disabled and locked."
 "86": "HW_DC_OVERCURRENT_AXIS - DC current too high during axis operation. Axis is disabled and locked."
 "87": "HW_DC_OVERCURRENT_ERROR - Global over current detected during operation. All axes are disabled and locked."
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_axisHealthStatus axisHealthStatus (0 = OK, not 0 = error code for detected short circuit condition)
*
*  @return axisHealthStatus (0 = OK, not 0 = error code for detected short circuit condition)
*/
int ATTOCUBE_API __AMC_1_5_1_control_getOutputHealthStatus(int deviceHandle, int axis, int* value_axisHealthStatus);

static inline int ATTO_FUNCTION(control_getOutputHealthStatus)(int deviceHandle, int axis, int* value_axisHealthStatus) {
    return __AMC_1_5_1_control_getOutputHealthStatus(deviceHandle, axis, value_axisHealthStatus);
}


/** @brief @AMC_control_resetOutputHealthStatus
*  This function resets the short circuit status of the selected axis.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param solution         Short description of taken measures to resolve the short circuit (min. 20 characters and 3 words, maximum 499 characters)
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_control_resetOutputHealthStatus(int deviceHandle, int axis, const char* solution);

static inline int ATTO_FUNCTION(control_resetOutputHealthStatus)(int deviceHandle, int axis, const char* solution) {
    return __AMC_1_5_1_control_resetOutputHealthStatus(deviceHandle, axis, solution);
}


/** @brief @AMC_control_setAutoMeasure
*  This function enables/disables the automatic C/R measurement on axis enable
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param enable           true: enable automeasurement, false: disable automeasurement
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_control_setAutoMeasure(int deviceHandle, int axis, bool enable);

static inline int ATTO_FUNCTION(control_setAutoMeasure)(int deviceHandle, int axis, bool enable) {
    return __AMC_1_5_1_control_setAutoMeasure(deviceHandle, axis, enable);
}


/** @brief @AMC_control_getAutoMeasure
*  This function returns if the automeasurement on axis enable is enabled
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_enable     enable true: enable automeasurement, false: disable automeasurement
*
*  @return enable true: enable automeasurement, false: disable automeasurement
*/
int ATTOCUBE_API __AMC_1_5_1_control_getAutoMeasure(int deviceHandle, int axis, bool* value_enable);

static inline int ATTO_FUNCTION(control_getAutoMeasure)(int deviceHandle, int axis, bool* value_enable) {
    return __AMC_1_5_1_control_getAutoMeasure(deviceHandle, axis, value_enable);
}


/** @brief @AMC_control_setActorSensitivity
*  Control the actor parameter closed loop sensitivity
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param sensitivity      [0 (fast approach) .. 10 (slow approach)]
 The approach behaviour changes exponentially with the sensitivity
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_control_setActorSensitivity(int deviceHandle, int axis, int sensitivity);

static inline int ATTO_FUNCTION(control_setActorSensitivity)(int deviceHandle, int axis, int sensitivity) {
    return __AMC_1_5_1_control_setActorSensitivity(deviceHandle, axis, sensitivity);
}


/** @brief @AMC_control_getActorSensitivity
*  Get the setting for the actor parameter sensitivity
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_sensitivity sensitivity [0 (fast approach) .. 10 (slow approach)]
 The approach behaviour changes exponentially with the sensitivity
*
*  @return sensitivity [0 (fast approach) .. 10 (slow approach)]
 The approach behaviour changes exponentially with the sensitivity
*/
int ATTOCUBE_API __AMC_1_5_1_control_getActorSensitivity(int deviceHandle, int axis, int* value_sensitivity);

static inline int ATTO_FUNCTION(control_getActorSensitivity)(int deviceHandle, int axis, int* value_sensitivity) {
    return __AMC_1_5_1_control_getActorSensitivity(deviceHandle, axis, value_sensitivity);
}


/** @brief @AMC_control_getActorParametersActorName
*  Control the actors parameter: actor name
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param actorname        actorname
*  @param size             Maximum size of buffer actorname
*
*  @return actorname
*/
int ATTOCUBE_API __AMC_1_5_1_control_getActorParametersActorName(int deviceHandle, int axis, char* actorname, int size);

static inline int ATTO_FUNCTION(control_getActorParametersActorName)(int deviceHandle, int axis, char* actorname, int size) {
    return __AMC_1_5_1_control_getActorParametersActorName(deviceHandle, axis, actorname, size);
}


/** @brief @AMC_control_setActorParametersByName
*  This function sets the name for the positioner on the selected axis. The possible names can be retrieved by executing getPositionersList
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param actorname        name of the actor
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_control_setActorParametersByName(int deviceHandle, int axis, const char* actorname);

static inline int ATTO_FUNCTION(control_setActorParametersByName)(int deviceHandle, int axis, const char* actorname) {
    return __AMC_1_5_1_control_setActorParametersByName(deviceHandle, axis, actorname);
}


/** @brief @AMC_control_getCurrentOutputVoltage
*  This function gets the current Voltage which is applied to the Piezo.
 Please note, that the actual values may be slightly different due to analog/digital converters, amplifiers, etc.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_amplitude  amplitude in mV
*
*  @return amplitude in mV
*/
int ATTOCUBE_API __AMC_1_5_1_control_getCurrentOutputVoltage(int deviceHandle, int axis, int* value_amplitude);

static inline int ATTO_FUNCTION(control_getCurrentOutputVoltage)(int deviceHandle, int axis, int* value_amplitude) {
    return __AMC_1_5_1_control_getCurrentOutputVoltage(deviceHandle, axis, value_amplitude);
}


/** @brief @AMC_control_getControlAmplitude
*  This function gets the amplitude of the actuator signal of the selected axis.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_amplitude  amplitude in mV
*
*  @return amplitude in mV
*/
int ATTOCUBE_API __AMC_1_5_1_control_getControlAmplitude(int deviceHandle, int axis, int* value_amplitude);

static inline int ATTO_FUNCTION(control_getControlAmplitude)(int deviceHandle, int axis, int* value_amplitude) {
    return __AMC_1_5_1_control_getControlAmplitude(deviceHandle, axis, value_amplitude);
}


/** @brief @AMC_control_setControlAmplitude
*  This function sets the amplitude of the actuator signal of the selected axis.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param amplitude        in mV
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_control_setControlAmplitude(int deviceHandle, int axis, int amplitude);

static inline int ATTO_FUNCTION(control_setControlAmplitude)(int deviceHandle, int axis, int amplitude) {
    return __AMC_1_5_1_control_setControlAmplitude(deviceHandle, axis, amplitude);
}


/** @brief @AMC_control_setControlFrequency
*  This function sets the frequency of the actuator signal of the selected axis.
  Note: Approximate the slewrate of the motion controller  according to Input Frequency
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param frequency        in  mHz
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_control_setControlFrequency(int deviceHandle, int axis, int frequency);

static inline int ATTO_FUNCTION(control_setControlFrequency)(int deviceHandle, int axis, int frequency) {
    return __AMC_1_5_1_control_setControlFrequency(deviceHandle, axis, frequency);
}


/** @brief @AMC_control_getControlFrequency
*  This function gets the frequency of the actuator signal of the selected axis.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_frequency  frequency in mHz
*
*  @return frequency in mHz
*/
int ATTOCUBE_API __AMC_1_5_1_control_getControlFrequency(int deviceHandle, int axis, int* value_frequency);

static inline int ATTO_FUNCTION(control_getControlFrequency)(int deviceHandle, int axis, int* value_frequency) {
    return __AMC_1_5_1_control_getControlFrequency(deviceHandle, axis, value_frequency);
}


/** @brief @AMC_control_getActorType
*  This function gets the type of the positioner of the selected axis.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_actor_type actor_type  0: linear, 1: rotator, 2: goniometer
*
*  @return actor_type  0: linear, 1: rotator, 2: goniometer
*/
int ATTOCUBE_API __AMC_1_5_1_control_getActorType(int deviceHandle, int axis, int* value_actor_type);

static inline int ATTO_FUNCTION(control_getActorType)(int deviceHandle, int axis, int* value_actor_type) {
    return __AMC_1_5_1_control_getActorType(deviceHandle, axis, value_actor_type);
}


/** @brief @AMC_control_getActorName
*  This function gets the name of the positioner of the selected axis.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param actor_name       actor_name
*  @param size             Maximum size of buffer actor_name
*
*  @return actor_name
*/
int ATTOCUBE_API __AMC_1_5_1_control_getActorName(int deviceHandle, int axis, char* actor_name, int size);

static inline int ATTO_FUNCTION(control_getActorName)(int deviceHandle, int axis, char* actor_name, int size) {
    return __AMC_1_5_1_control_getActorName(deviceHandle, axis, actor_name, size);
}


/** @brief @AMC_control_setReset
*  This function resets the actual position of the selected axis given by the NUM sensor to zero and marks the reference position as invalid.
 It does not work for RES positioners and positions read by IDS.
 For IDS, use com.attocube.ids.displacement.resetAxis() or com.attocube.amc.amcids.resetIdsAxis() instead.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_control_setReset(int deviceHandle, int axis);

static inline int ATTO_FUNCTION(control_setReset)(int deviceHandle, int axis) {
    return __AMC_1_5_1_control_setReset(deviceHandle, axis);
}


/** @brief @AMC_control_setControlMove
*  This function sets the approach of the selected axis’ positioner to the target position.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param enable           boolean true: eanble the approach , false: disable the approach
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_control_setControlMove(int deviceHandle, int axis, bool enable);

static inline int ATTO_FUNCTION(control_setControlMove)(int deviceHandle, int axis, bool enable) {
    return __AMC_1_5_1_control_setControlMove(deviceHandle, axis, enable);
}


/** @brief @AMC_control_getControlMove
*  This function gets the approach of the selected axis’ positioner to the target position.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_enable     enable boolean true: closed loop control enabled, false: closed loop control disabled
*
*  @return enable boolean true: closed loop control enabled, false: closed loop control disabled
*/
int ATTOCUBE_API __AMC_1_5_1_control_getControlMove(int deviceHandle, int axis, bool* value_enable);

static inline int ATTO_FUNCTION(control_getControlMove)(int deviceHandle, int axis, bool* value_enable) {
    return __AMC_1_5_1_control_getControlMove(deviceHandle, axis, value_enable);
}


/** @brief @AMC_control_searchReferencePosition
*  This function searches for the reference position of the selected axis.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_control_searchReferencePosition(int deviceHandle, int axis);

static inline int ATTO_FUNCTION(control_searchReferencePosition)(int deviceHandle, int axis) {
    return __AMC_1_5_1_control_searchReferencePosition(deviceHandle, axis);
}


/** @brief @AMC_control_getReferencePosition
*  This function gets the reference position of the selected axis.
 It can only be used in conjunction with NUM.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_position   position: For linear type actors the position is defined in nm for goniometer an rotator type actors it is µ°.
*
*  @return position: For linear type actors the position is defined in nm for goniometer an rotator type actors it is µ°.
*/
int ATTOCUBE_API __AMC_1_5_1_control_getReferencePosition(int deviceHandle, int axis, int* value_position);

static inline int ATTO_FUNCTION(control_getReferencePosition)(int deviceHandle, int axis, int* value_position) {
    return __AMC_1_5_1_control_getReferencePosition(deviceHandle, axis, value_position);
}


/** @brief @AMC_control_getControlReferenceAutoUpdate
*  This function gets the status of whether the reference position is updated when the reference mark is hit
When this function is disabled, the reference marking will be considered only the first time and after then ignored
this setting only has an effect for NUM-positioners.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_enabled    enabled boolen
*
*  @return enabled boolen
*/
int ATTOCUBE_API __AMC_1_5_1_control_getControlReferenceAutoUpdate(int deviceHandle, int axis, bool* value_enabled);

static inline int ATTO_FUNCTION(control_getControlReferenceAutoUpdate)(int deviceHandle, int axis, bool* value_enabled) {
    return __AMC_1_5_1_control_getControlReferenceAutoUpdate(deviceHandle, axis, value_enabled);
}


/** @brief @AMC_control_setControlReferenceAutoUpdate
*  This function sets the status of whether the reference position is updated when the reference mark is hit.
 When this function is disabled, the reference marking will be considered only the first time and after then ignored.
 This function can only be used in conjunction with NUM.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param enable           boolean
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_control_setControlReferenceAutoUpdate(int deviceHandle, int axis, bool enable);

static inline int ATTO_FUNCTION(control_setControlReferenceAutoUpdate)(int deviceHandle, int axis, bool enable) {
    return __AMC_1_5_1_control_setControlReferenceAutoUpdate(deviceHandle, axis, enable);
}


/** @brief @AMC_control_getControlAutoReset
*  This function resets the position every time the reference position is detected
this setting only has an effect for NUM-positioners.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_enabled    enabled boolean
*
*  @return enabled boolean
*/
int ATTOCUBE_API __AMC_1_5_1_control_getControlAutoReset(int deviceHandle, int axis, bool* value_enabled);

static inline int ATTO_FUNCTION(control_getControlAutoReset)(int deviceHandle, int axis, bool* value_enabled) {
    return __AMC_1_5_1_control_getControlAutoReset(deviceHandle, axis, value_enabled);
}


/** @brief @AMC_control_setControlAutoReset
*  This function controls the behaviour, that the current position (which can be retrieved with a getPosition-call) is reset every time the reference mark of the positioner is detected.
 This function can only be used in conjunction with NUM.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param enable           boolean
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_control_setControlAutoReset(int deviceHandle, int axis, bool enable);

static inline int ATTO_FUNCTION(control_setControlAutoReset)(int deviceHandle, int axis, bool enable) {
    return __AMC_1_5_1_control_setControlAutoReset(deviceHandle, axis, enable);
}


/** @brief @AMC_control_getControlTargetRange
*  This function gets the range around the target position in which the flag "In Target Range" becomes active.
 Please note, that this setting is only used to identify the target position, it has no influence on the closed loop control.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_targetrange targetrange in nm
*
*  @return targetrange in nm
*/
int ATTOCUBE_API __AMC_1_5_1_control_getControlTargetRange(int deviceHandle, int axis, int* value_targetrange);

static inline int ATTO_FUNCTION(control_getControlTargetRange)(int deviceHandle, int axis, int* value_targetrange) {
    return __AMC_1_5_1_control_getControlTargetRange(deviceHandle, axis, value_targetrange);
}


/** @brief @AMC_control_setControlTargetRange
*  This function sets the range around the target position in which the flag "In Target Range" (see VIII.7.a) becomes active.
 Please note, that this setting is only used to identify the target position, it has no influence on the closed loop control.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param range            in nm
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_control_setControlTargetRange(int deviceHandle, int axis, int range);

static inline int ATTO_FUNCTION(control_setControlTargetRange)(int deviceHandle, int axis, int range) {
    return __AMC_1_5_1_control_setControlTargetRange(deviceHandle, axis, range);
}


/** @brief @AMC_control_MultiAxisPositioning
*  By means of this function you can set target positions for all axes simultaneously (depending on the boolean parameters set1, set2, set3)
 Additionally the current position, the status of the reference and the reference position of all three axes are returned.
 This function can only be used in conjunction with NUM.
*
*  @param deviceHandle     Handle of device
*  @param set1             set target position on axis1, if "false" target1-parameter is ignored
*  @param set2             set target position on axis2, if "false" target2-parameter is ignored
*  @param set3             set target position on axis3, if "false" target3-parameter is ignored
*  @param target1          target position of axis 1
*  @param target2          target position of axis 2
*  @param target3          target position of axis 3
*
*  @param value_ref1       ref1 Status of axis 1
*  @param value_ref2       ref2 Status of axis 2
*  @param value_ref3       ref3 Status of axis 3
*  @param value_refpos1    refpos1 reference Position of axis 1
*  @param value_refpos2    refpos2 reference Position of axis 2
*  @param value_refpos3    refpos3 reference Position of axis 3
*  @param value_pos1       pos1 position of axis 1
*  @param value_pos2       pos2 position of axis 2
*  @param value_pos3       pos3 position of axis 3
*
*  @return ref1 Status of axis 1
*/
int ATTOCUBE_API __AMC_1_5_1_control_MultiAxisPositioning(int deviceHandle, bool set1, bool set2, bool set3, int target1, int target2, int target3, bool* value_ref1, bool* value_ref2, bool* value_ref3, int* value_refpos1, int* value_refpos2, int* value_refpos3, int* value_pos1, int* value_pos2, int* value_pos3);

static inline int ATTO_FUNCTION(control_MultiAxisPositioning)(int deviceHandle, bool set1, bool set2, bool set3, int target1, int target2, int target3, bool* value_ref1, bool* value_ref2, bool* value_ref3, int* value_refpos1, int* value_refpos2, int* value_refpos3, int* value_pos1, int* value_pos2, int* value_pos3) {
    return __AMC_1_5_1_control_MultiAxisPositioning(deviceHandle, set1, set2, set3, target1, target2, target3, value_ref1, value_ref2, value_ref3, value_refpos1, value_refpos2, value_refpos3, value_pos1, value_pos2, value_pos3);
}


/** @brief @AMC_control_MultiAxisPositioningWithTime
*  In addition to "MultiAxisPositioning", this function returns a timestamp to the current position of each axis.
 Please refer to the description of "getPositionWithTime" for more information on the timestamp.
 This function can only be used in conjunction with NUM.
*
*  @param deviceHandle     Handle of device
*  @param set1             set target position on axis1, if "false" target1-parameter is ignored
*  @param set2             set target position on axis2, if "false" target2-parameter is ignored
*  @param set3             set target position on axis3, if "false" target3-parameter is ignored
*  @param target1          target position of axis 1
*  @param target2          target position of axis 2
*  @param target3          target position of axis 3
*
*  @param value_ref1       ref1 Status of axis 1
*  @param value_ref2       ref2 Status of axis 2
*  @param value_ref3       ref3 Status of axis 3
*  @param value_refpos1    refpos1 reference Position of axis 1
*  @param value_refpos2    refpos2 reference Position of axis 2
*  @param value_refpos3    refpos3 reference Position of axis 3
*  @param value_pos1       pos1 position of axis 1
*  @param value_pos2       pos2 position of axis 2
*  @param value_pos3       pos3 position of axis 3
*  @param value_time1      time1 timestamp of axis 1
*  @param value_time2      time2 timestamp of axis 2
*  @param value_time3      time3 timestamp of axis 3
*
*  @return ref1 Status of axis 1
*/
int ATTOCUBE_API __AMC_1_5_1_control_MultiAxisPositioningWithTime(int deviceHandle, bool set1, bool set2, bool set3, int target1, int target2, int target3, bool* value_ref1, bool* value_ref2, bool* value_ref3, int* value_refpos1, int* value_refpos2, int* value_refpos3, int* value_pos1, int* value_pos2, int* value_pos3, double* value_time1, double* value_time2, double* value_time3);

static inline int ATTO_FUNCTION(control_MultiAxisPositioningWithTime)(int deviceHandle, bool set1, bool set2, bool set3, int target1, int target2, int target3, bool* value_ref1, bool* value_ref2, bool* value_ref3, int* value_refpos1, int* value_refpos2, int* value_refpos3, int* value_pos1, int* value_pos2, int* value_pos3, double* value_time1, double* value_time2, double* value_time3) {
    return __AMC_1_5_1_control_MultiAxisPositioningWithTime(deviceHandle, set1, set2, set3, target1, target2, target3, value_ref1, value_ref2, value_ref3, value_refpos1, value_refpos2, value_refpos3, value_pos1, value_pos2, value_pos3, value_time1, value_time2, value_time3);
}


/** @brief @AMC_control_getPositionsAndVoltages
*  Simultaneously get 3 axes positions as well as the DC offset
 position-value is -2147483648 nm, if sensor is disabled or no positioner is connected.
*
*  @param deviceHandle     Handle of device
*
*  @param value_pos1       pos1 position of axis 1
*  @param value_pos2       pos2 position of axis 2
*  @param value_pos3       pos3 position of axis 3
*  @param value_val1       val1 dc voltage of of axis 1 in mV
*  @param value_val2       val2 dc voltage of of axis 2 in mV
*  @param value_val3       val3 dc voltage of of axis 3 in mV
*
*  @return pos1 position of axis 1
*/
int ATTOCUBE_API __AMC_1_5_1_control_getPositionsAndVoltages(int deviceHandle, double* value_pos1, double* value_pos2, double* value_pos3, int* value_val1, int* value_val2, int* value_val3);

static inline int ATTO_FUNCTION(control_getPositionsAndVoltages)(int deviceHandle, double* value_pos1, double* value_pos2, double* value_pos3, int* value_val1, int* value_val2, int* value_val3) {
    return __AMC_1_5_1_control_getPositionsAndVoltages(deviceHandle, value_pos1, value_pos2, value_pos3, value_val1, value_val2, value_val3);
}


/** @brief @AMC_control_getStatusMovingAllAxes
*  Get Status of all axes, see getStatusMoving for coding of the values
*
*  @param deviceHandle     Handle of device
*
*  @param value_moving1    moving1 status of axis 1
*  @param value_moving2    moving2 status of axis 2
*  @param value_moving3    moving3 status of axis 3
*
*  @return moving1 status of axis 1
*/
int ATTOCUBE_API __AMC_1_5_1_control_getStatusMovingAllAxes(int deviceHandle, int* value_moving1, int* value_moving2, int* value_moving3);

static inline int ATTO_FUNCTION(control_getStatusMovingAllAxes)(int deviceHandle, int* value_moving1, int* value_moving2, int* value_moving3) {
    return __AMC_1_5_1_control_getStatusMovingAllAxes(deviceHandle, value_moving1, value_moving2, value_moving3);
}


/** @brief @AMC_move_getPositionAllAxis
*  This function returns the position of all three axes in nm
 If there is no positioner on one axis or the sensor is disabled, it returns -2147483648 nm instead
*
*  @param deviceHandle     Handle of device
*
*  @param err              err
*  @param value_pos_nm_x   pos_nm_x position of the x-axis in nm
*  @param value_pos_nm_y   pos_nm_y position of the y-axis in nm
*  @param value_pos_nm_z   pos_nm_z position of the z-axis in nm
*
*  @return err
*/
int ATTOCUBE_API __AMC_1_5_1_move_getPositionAllAxis(int deviceHandle, int* err, double* value_pos_nm_x, double* value_pos_nm_y, double* value_pos_nm_z);

static inline int ATTO_FUNCTION(move_getPositionAllAxis)(int deviceHandle, int* err, double* value_pos_nm_x, double* value_pos_nm_y, double* value_pos_nm_z) {
    return __AMC_1_5_1_move_getPositionAllAxis(deviceHandle, err, value_pos_nm_x, value_pos_nm_y, value_pos_nm_z);
}


/** @brief @AMC_status_getStatusFlagsAllAxis
*  This function returns several status flags of all three axes
*
*  @param deviceHandle     Handle of device
*
*  @param err              err
*  @param value_pos_con_ax1 pos_con_ax1 positioner connected axis 1
*  @param value_enbld_ax1  enbld_ax1 Axis 1 enabled
*  @param value_moving_ax1 moving_ax1 axis 1 moving
*  @param value_in_trgt_ax1 in_trgt_ax1 axis 1 in target range
*  @param value_eot_fwd_ax1 eot_fwd_ax1 axis 1 eot fwd flag
*  @param value_eot_bwd_ax1 eot_bwd_ax1 axis 1 eot bwd flag
*  @param value_gnd_ax1    gnd_ax1 axis 1 grounded (e.g. ground on target)
*  @param value_pos_con_ax2 pos_con_ax2 positioner connected axis 2
*  @param value_enbld_ax2  enbld_ax2 Axis 2 enabled
*  @param value_moving_ax2 moving_ax2 axis 2 moving
*  @param value_in_trgt_ax2 in_trgt_ax2 axis 2 in target range
*  @param value_eot_fwd_ax2 eot_fwd_ax2 axis 2 eot fwd flag
*  @param value_eot_bwd_ax2 eot_bwd_ax2 axis 2 eot bwd flag
*  @param value_gnd_ax2    gnd_ax2 axis 2 grounded (e.g. ground on target)
*  @param value_pos_con_ax3 pos_con_ax3 positioner connected axis 3
*  @param value_enbld_ax3  enbld_ax3 Axis 3 enabled
*  @param value_moving_ax3 moving_ax3 axis 3 moving
*  @param value_in_trgt_ax3 in_trgt_ax3 axis 3 in target range
*  @param value_eot_fwd_ax3 eot_fwd_ax3 axis 3 eot fwd flag
*  @param value_eot_bwd_ax3 eot_bwd_ax3 axis 3 eot bwd flag
*  @param value_gnd_ax3    gnd_ax3 axis 3 grounded (e.g. ground on target)
*
*  @return err
*/
int ATTOCUBE_API __AMC_1_5_1_status_getStatusFlagsAllAxis(int deviceHandle, int* err, bool* value_pos_con_ax1, bool* value_enbld_ax1, bool* value_moving_ax1, bool* value_in_trgt_ax1, bool* value_eot_fwd_ax1, bool* value_eot_bwd_ax1, bool* value_gnd_ax1, bool* value_pos_con_ax2, bool* value_enbld_ax2, bool* value_moving_ax2, bool* value_in_trgt_ax2, bool* value_eot_fwd_ax2, bool* value_eot_bwd_ax2, bool* value_gnd_ax2, bool* value_pos_con_ax3, bool* value_enbld_ax3, bool* value_moving_ax3, bool* value_in_trgt_ax3, bool* value_eot_fwd_ax3, bool* value_eot_bwd_ax3, bool* value_gnd_ax3);

static inline int ATTO_FUNCTION(status_getStatusFlagsAllAxis)(int deviceHandle, int* err, bool* value_pos_con_ax1, bool* value_enbld_ax1, bool* value_moving_ax1, bool* value_in_trgt_ax1, bool* value_eot_fwd_ax1, bool* value_eot_bwd_ax1, bool* value_gnd_ax1, bool* value_pos_con_ax2, bool* value_enbld_ax2, bool* value_moving_ax2, bool* value_in_trgt_ax2, bool* value_eot_fwd_ax2, bool* value_eot_bwd_ax2, bool* value_gnd_ax2, bool* value_pos_con_ax3, bool* value_enbld_ax3, bool* value_moving_ax3, bool* value_in_trgt_ax3, bool* value_eot_fwd_ax3, bool* value_eot_bwd_ax3, bool* value_gnd_ax3) {
    return __AMC_1_5_1_status_getStatusFlagsAllAxis(deviceHandle, err, value_pos_con_ax1, value_enbld_ax1, value_moving_ax1, value_in_trgt_ax1, value_eot_fwd_ax1, value_eot_bwd_ax1, value_gnd_ax1, value_pos_con_ax2, value_enbld_ax2, value_moving_ax2, value_in_trgt_ax2, value_eot_fwd_ax2, value_eot_bwd_ax2, value_gnd_ax2, value_pos_con_ax3, value_enbld_ax3, value_moving_ax3, value_in_trgt_ax3, value_eot_fwd_ax3, value_eot_bwd_ax3, value_gnd_ax3);
}


/** @brief @AMC_status_getStatusFlagsAllAxesJson
*  This function returns several status flags from all axes as json-string.
 The json-string has the following structure (please note, that json does not gurantee the order of the entries, i.e. axis_1 may be the second or last entry in the function return value):
 {
*    "axis_1": {
*        "<name of status-flag>": true|false,
*        ...
*    },
*    "axis_2": {
*        "<name of status-flag>": true|false,
*        ...
*    },
*    "axis_3": {
*        "<name of status-flag>": true|false,
*        ...
*    }
 }
 The following status flags are included in the json-string (please note, that json does not guarantee the order of the entries, i.e. "actuator_connected" may be at a different position within the "axis_X"-field):
 - actuator_connected: indicates whether a positioner is connected to the axis (for more information please refer to getStatusConnected)
 - axis_active: indicates whether the axis is active (enabled) (for more information please refer to getControlOutput)
 - moving: indicates whether the axis is currently moving (for more information please refer to getStatusMoving)
 - in_target_range: indicates whether the positioner is in target range (for more information please refer to getStatusTargetRange)
 - eot_fwd: indicates whether the forward end of travel has been reached (for more information please refer to getStatusEotFwd)
 - eot_bwd: indicates whether the backward end of travel has been reached (for more information please refer to getStatusEotBkwd)
 - axis_grounded: indicates whether the axis is grounded (e.g. ground on target) (for more information please refer to getGroundAxis)
 - short_detected: indicates whether a Short circuit has been detected on the axis (for more information please refer to getOutputHealthStatus)
*
*  @param deviceHandle     Handle of device
*
*  @param err              err
*  @param value_statusFlagsJson statusFlagsJson json-string containing the status flags of all axes (please refer to the interface manual for more information)
*  @param size             Maximum size of buffer value_statusFlagsJson
*
*  @return err
*/
int ATTOCUBE_API __AMC_1_5_1_status_getStatusFlagsAllAxesJson(int deviceHandle, int* err, char* value_statusFlagsJson, int size);

static inline int ATTO_FUNCTION(status_getStatusFlagsAllAxesJson)(int deviceHandle, int* err, char* value_statusFlagsJson, int size) {
    return __AMC_1_5_1_status_getStatusFlagsAllAxesJson(deviceHandle, err, value_statusFlagsJson, size);
}


/** @brief @AMC_control_getMoveParametersAllAxis
*  This function reads the parameters for controling the positioners on all three axes
 The parameters are ampltidue (V), sawtooth-frequency (Hz), currently on the piezo applied voltage (V)
*
*  @param deviceHandle     Handle of device
*
*  @param err              err
*  @param amplitude_ax1_mV amplitude_ax1_mV
*  @param frequency_ax1_mHz frequency_ax1_mHz
*  @param value_appliedVoltage_ax_mV1 appliedVoltage_ax1_mV currently applied "DC"-Voltage
*  @param amplitude_ax2_mV amplitude_ax2_mV
*  @param frequency_ax2_mHz frequency_ax2_mHz
*  @param value_appliedVoltage_ax_mV2 appliedVoltage_ax2_mV currently applied "DC"-Voltage
*  @param amplitude_ax3_mV amplitude_ax3_mV
*  @param frequency_ax3_mHz frequency_ax3_mHz
*  @param value_appliedVoltage_ax_mV3 appliedVoltage_ax3_mV currently applied "DC"-Voltage
*
*  @return err
*/
int ATTOCUBE_API __AMC_1_5_1_control_getMoveParametersAllAxis(int deviceHandle, int* err, int* amplitude_ax1_mV, int* frequency_ax1_mHz, int* value_appliedVoltage_ax_mV1, int* amplitude_ax2_mV, int* frequency_ax2_mHz, int* value_appliedVoltage_ax_mV2, int* amplitude_ax3_mV, int* frequency_ax3_mHz, int* value_appliedVoltage_ax_mV3);

static inline int ATTO_FUNCTION(control_getMoveParametersAllAxis)(int deviceHandle, int* err, int* amplitude_ax1_mV, int* frequency_ax1_mHz, int* value_appliedVoltage_ax_mV1, int* amplitude_ax2_mV, int* frequency_ax2_mHz, int* value_appliedVoltage_ax_mV2, int* amplitude_ax3_mV, int* frequency_ax3_mHz, int* value_appliedVoltage_ax_mV3) {
    return __AMC_1_5_1_control_getMoveParametersAllAxis(deviceHandle, err, amplitude_ax1_mV, frequency_ax1_mHz, value_appliedVoltage_ax_mV1, amplitude_ax2_mV, frequency_ax2_mHz, value_appliedVoltage_ax_mV2, amplitude_ax3_mV, frequency_ax3_mHz, value_appliedVoltage_ax_mV3);
}


/** @brief @AMC_control_setControlFixOutputVoltage
*  This function sets the DC level output of the selected axis.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param amplitude_mv     in mV
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_control_setControlFixOutputVoltage(int deviceHandle, int axis, int amplitude_mv);

static inline int ATTO_FUNCTION(control_setControlFixOutputVoltage)(int deviceHandle, int axis, int amplitude_mv) {
    return __AMC_1_5_1_control_setControlFixOutputVoltage(deviceHandle, axis, amplitude_mv);
}


/** @brief @AMC_control_getControlFixOutputVoltage
*  This function gets the DC level output of the selected axis.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_amplitude_mv amplitude_mv in mV
*
*  @return amplitude_mv in mV
*/
int ATTOCUBE_API __AMC_1_5_1_control_getControlFixOutputVoltage(int deviceHandle, int axis, int* value_amplitude_mv);

static inline int ATTO_FUNCTION(control_getControlFixOutputVoltage)(int deviceHandle, int axis, int* value_amplitude_mv) {
    return __AMC_1_5_1_control_getControlFixOutputVoltage(deviceHandle, axis, value_amplitude_mv);
}


/** @brief @AMC_move_setGroundAxis
*  Pull axis piezo drive to GND actively.
 Please note, that this function can only be used on an active axis (see setControlOutput)
 This function is only available on AMC300 devices.
*
*  @param deviceHandle     Handle of device
*  @param axis             motion controler axis [0|1|2]
*  @param enabled          true or false
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_move_setGroundAxis(int deviceHandle, int axis, bool enabled);

static inline int ATTO_FUNCTION(move_setGroundAxis)(int deviceHandle, int axis, bool enabled) {
    return __AMC_1_5_1_move_setGroundAxis(deviceHandle, axis, enabled);
}


/** @brief @AMC_move_getGroundAxis
*  Checks if the axis piezo drive is actively grounded.
 Please note, that this function only returns whether or not tha axis is grounded. To get the axis activation status, please use getControlOutput.
 This function is only available on AMC300 devices.
*
*  @param deviceHandle     Handle of device
*  @param axis             montion controler axis [0|1|2]
*
*  @param value_grounded   grounded true or false
*
*  @return grounded true or false
*/
int ATTOCUBE_API __AMC_1_5_1_move_getGroundAxis(int deviceHandle, int axis, bool* value_grounded);

static inline int ATTO_FUNCTION(move_getGroundAxis)(int deviceHandle, int axis, bool* value_grounded) {
    return __AMC_1_5_1_move_getGroundAxis(deviceHandle, axis, value_grounded);
}


/** @brief @AMC_move_setGroundAxisAutoOnTarget
*  Pull axis piezo drive to GND actively if positioner is in ground target range
 only in AMC300
 this is used in MIC-Mode
*
*  @param deviceHandle     Handle of device
*  @param axis             montion controler axis [0|1|2]
*  @param enabled          true or false
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_move_setGroundAxisAutoOnTarget(int deviceHandle, int axis, bool enabled);

static inline int ATTO_FUNCTION(move_setGroundAxisAutoOnTarget)(int deviceHandle, int axis, bool enabled) {
    return __AMC_1_5_1_move_setGroundAxisAutoOnTarget(deviceHandle, axis, enabled);
}


/** @brief @AMC_move_getGroundAxisAutoOnTarget
*  Pull axis piezo drive to GND if positioner is in ground target range
 only in AMC300
*
*  @param deviceHandle     Handle of device
*  @param axis             montion controler axis [0|1|2]
*
*  @param value_value      value true or false
*
*  @return value true or false
*/
int ATTOCUBE_API __AMC_1_5_1_move_getGroundAxisAutoOnTarget(int deviceHandle, int axis, bool* value_value);

static inline int ATTO_FUNCTION(move_getGroundAxisAutoOnTarget)(int deviceHandle, int axis, bool* value_value) {
    return __AMC_1_5_1_move_getGroundAxisAutoOnTarget(deviceHandle, axis, value_value);
}


/** @brief @AMC_control_setGndIfIdle
*  sets the ground-if-idle feature active or inactive
 Please note, that changing this setting to false while the axis is active will deactivate the axis
 This function cannot be executed during open- or closed-loop movement on the given axis
 This feature is only available for AMC300.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param gndifidleAct     [0: inactive; 1: active]
*
*  @param err              err
*
*  @return err
*/
int ATTOCUBE_API __AMC_1_5_1_control_setGndIfIdle(int deviceHandle, int axis, int gndifidleAct, int* err);

static inline int ATTO_FUNCTION(control_setGndIfIdle)(int deviceHandle, int axis, int gndifidleAct, int* err) {
    return __AMC_1_5_1_control_setGndIfIdle(deviceHandle, axis, gndifidleAct, err);
}


/** @brief @AMC_control_getGndIfIdle
*  gets whether ground-if-idle shall be active or deactivate
 only in AMC300
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param err              err
*  @param value_gndifidleAct gndifidleAct [0: inactive; 1: active]
*
*  @return err
*/
int ATTOCUBE_API __AMC_1_5_1_control_getGndIfIdle(int deviceHandle, int axis, int* err, int* value_gndifidleAct);

static inline int ATTO_FUNCTION(control_getGndIfIdle)(int deviceHandle, int axis, int* err, int* value_gndifidleAct) {
    return __AMC_1_5_1_control_getGndIfIdle(deviceHandle, axis, err, value_gndifidleAct);
}


/** @brief @AMC_move_getGroundTargetRange
*  Retrieves the range around the target position in which the auto grounding becomes active.
 only in AMC300
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_targetrange targetrange in nm
*
*  @return targetrange in nm
*/
int ATTOCUBE_API __AMC_1_5_1_move_getGroundTargetRange(int deviceHandle, int axis, int* value_targetrange);

static inline int ATTO_FUNCTION(move_getGroundTargetRange)(int deviceHandle, int axis, int* value_targetrange) {
    return __AMC_1_5_1_move_getGroundTargetRange(deviceHandle, axis, value_targetrange);
}


/** @brief @AMC_move_setGroundTargetRange
*  Set  the range around the target position in which the auto grounding becomes active.
 only in AMC300
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param range            in nm
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_move_setGroundTargetRange(int deviceHandle, int axis, int range);

static inline int ATTO_FUNCTION(move_setGroundTargetRange)(int deviceHandle, int axis, int range) {
    return __AMC_1_5_1_move_setGroundTargetRange(deviceHandle, axis, range);
}


/** @brief @AMC_control_setSensorEnabled
*  Set sensor power supply status, can be switched off to save heat generated by sensor [NUM or RES]; no effect on IDS in AMC-IDS-CL feature
 Positions retrieved will be invalid when activating this, so closed-loop control should be switched off beforehand
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param value            true if enabled, false otherwise
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_control_setSensorEnabled(int deviceHandle, int axis, bool value);

static inline int ATTO_FUNCTION(control_setSensorEnabled)(int deviceHandle, int axis, bool value) {
    return __AMC_1_5_1_control_setSensorEnabled(deviceHandle, axis, value);
}


/** @brief @AMC_control_getSensorEnabled
*  Get sensor power supply status
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_value      value true if enabled, false otherwise
*
*  @return value true if enabled, false otherwise
*/
int ATTOCUBE_API __AMC_1_5_1_control_getSensorEnabled(int deviceHandle, int axis, bool* value_value);

static inline int ATTO_FUNCTION(control_getSensorEnabled)(int deviceHandle, int axis, bool* value_value) {
    return __AMC_1_5_1_control_getSensorEnabled(deviceHandle, axis, value_value);
}


/** @brief @AMC_control_getFinePositioningRange
*  This function gets the fine positioning DC-range
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_range      range in nm
*
*  @return range in nm
*/
int ATTOCUBE_API __AMC_1_5_1_control_getFinePositioningRange(int deviceHandle, int axis, int* value_range);

static inline int ATTO_FUNCTION(control_getFinePositioningRange)(int deviceHandle, int axis, int* value_range) {
    return __AMC_1_5_1_control_getFinePositioningRange(deviceHandle, axis, value_range);
}


/** @brief @AMC_control_setFinePositioningRange
*  This function sets the fine positioning DC-range
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param range            in nm
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_control_setFinePositioningRange(int deviceHandle, int axis, int range);

static inline int ATTO_FUNCTION(control_setFinePositioningRange)(int deviceHandle, int axis, int range) {
    return __AMC_1_5_1_control_setFinePositioningRange(deviceHandle, axis, range);
}


/** @brief @AMC_control_getFinePositioningSlewRate
*  This function gets the fine positioning slew rate
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_slewrate   slewrate [0|1|2|3]
*
*  @return slewrate [0|1|2|3]
*/
int ATTOCUBE_API __AMC_1_5_1_control_getFinePositioningSlewRate(int deviceHandle, int axis, int* value_slewrate);

static inline int ATTO_FUNCTION(control_getFinePositioningSlewRate)(int deviceHandle, int axis, int* value_slewrate) {
    return __AMC_1_5_1_control_getFinePositioningSlewRate(deviceHandle, axis, value_slewrate);
}


/** @brief @AMC_control_setFinePositioningSlewRate
*  This function sets the fine positioning slew rate
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param slewrate         [0|1|2|3]
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_control_setFinePositioningSlewRate(int deviceHandle, int axis, int slewrate);

static inline int ATTO_FUNCTION(control_setFinePositioningSlewRate)(int deviceHandle, int axis, int slewrate) {
    return __AMC_1_5_1_control_setFinePositioningSlewRate(deviceHandle, axis, slewrate);
}


/** @brief @AMC_diagnostic_startDiagnostic
*  Start the diagnosis procedure for the given axis
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_diagnostic_startDiagnostic(int deviceHandle, int axis);

static inline int ATTO_FUNCTION(diagnostic_startDiagnostic)(int deviceHandle, int axis) {
    return __AMC_1_5_1_diagnostic_startDiagnostic(deviceHandle, axis);
}


/** @brief @AMC_diagnostic_getDiagnosticResults
*  Returns the results of the last diagnostic run and an error, if there was no run, it is currently running or the run failed
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_capacity   capacity in nF
*  @param value_resistance resistance in Ohm
*
*  @return capacity in nF
*/
int ATTOCUBE_API __AMC_1_5_1_diagnostic_getDiagnosticResults(int deviceHandle, int axis, int* value_capacity, int* value_resistance);

static inline int ATTO_FUNCTION(diagnostic_getDiagnosticResults)(int deviceHandle, int axis, int* value_capacity, int* value_resistance) {
    return __AMC_1_5_1_diagnostic_getDiagnosticResults(deviceHandle, axis, value_capacity, value_resistance);
}


/** @brief @AMC_diagnostic_getDiagnosticPower
*  Returns the current power consumption
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param power            power
*
*  @return power
*/
int ATTOCUBE_API __AMC_1_5_1_diagnostic_getDiagnosticPower(int deviceHandle, int axis, int* power);

static inline int ATTO_FUNCTION(diagnostic_getDiagnosticPower)(int deviceHandle, int axis, int* power) {
    return __AMC_1_5_1_diagnostic_getDiagnosticPower(deviceHandle, axis, power);
}


/** @brief @AMC_diagnostic_getDiagnosticTemperature
*  Returns the current axis temperature
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param temperature      temperature
*
*  @return temperature
*/
int ATTOCUBE_API __AMC_1_5_1_diagnostic_getDiagnosticTemperature(int deviceHandle, int axis, int* temperature);

static inline int ATTO_FUNCTION(diagnostic_getDiagnosticTemperature)(int deviceHandle, int axis, int* temperature) {
    return __AMC_1_5_1_diagnostic_getDiagnosticTemperature(deviceHandle, axis, temperature);
}


/** @brief @AMC_res_setChainGain
*  Set signal chain gain to control overall power
*
*  @param deviceHandle     Handle of device
*  @param axis             number of axis
*  @param gainconfig       0: 0dB ( power 600mVpkpk^2/R), 1 : -10 dB , 2 : -15 dB , 3 : -20 dB
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_res_setChainGain(int deviceHandle, int axis, int gainconfig);

static inline int ATTO_FUNCTION(res_setChainGain)(int deviceHandle, int axis, int gainconfig) {
    return __AMC_1_5_1_res_setChainGain(deviceHandle, axis, gainconfig);
}


/** @brief @AMC_res_getChainGain
*  Get chain gain, see setChainGain for parameter description
*
*  @param deviceHandle     Handle of device
*  @param axis             number of axis
*
*  @param value_gaincoeff  gaincoeff or voltage in mV for dcres
*
*  @return gaincoeff or voltage in mV for dcres
*/
int ATTOCUBE_API __AMC_1_5_1_res_getChainGain(int deviceHandle, int axis, int* value_gaincoeff);

static inline int ATTO_FUNCTION(res_getChainGain)(int deviceHandle, int axis, int* value_gaincoeff) {
    return __AMC_1_5_1_res_getChainGain(deviceHandle, axis, value_gaincoeff);
}


/** @brief @AMC_res_getLutSn
*  get the identifier of the loaded lookuptable (will be empty if disabled)
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_string     string : identifier
*  @param size             Maximum size of buffer value_string
*
*  @return string : identifier
*/
int ATTOCUBE_API __AMC_1_5_1_res_getLutSn(int deviceHandle, int axis, char* value_string, int size);

static inline int ATTO_FUNCTION(res_getLutSn)(int deviceHandle, int axis, char* value_string, int size) {
    return __AMC_1_5_1_res_getLutSn(deviceHandle, axis, value_string, size);
}


/** @brief @AMC_res_setConfigurationFile
*  Load configuration file which either contains a JSON dict with parameters for the positioner on the axis or the LUT file itself (as legacy support for ANC350 .aps files)
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param content          JSON Dictionary or .aps File.
 The JSON Dictonary can/must contain the following keys:
 'type': mandatory This field has to be one of the positioner list (see getPositionersList)
 'lut': optional, contains an array of 1024 LUT values that are a mapping between ratio of the RES element travelled (0 to 1) and the corresponding absolute value at this ratio given in [nm].
 Note: when generating these tables with position data in absolute units, the scaling of the travel ratio with the current sensor range has to be reversed.
 'lut_sn': optional, a string to uniquely identify the loaded LUT
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_res_setConfigurationFile(int deviceHandle, int axis, const char* content);

static inline int ATTO_FUNCTION(res_setConfigurationFile)(int deviceHandle, int axis, const char* content) {
    return __AMC_1_5_1_res_setConfigurationFile(deviceHandle, axis, content);
}


/** @brief @AMC_res_getLinearization
*  Gets wether linearization is enabled or not
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_enabled    enabled true when enabled
*
*  @return enabled true when enabled
*/
int ATTOCUBE_API __AMC_1_5_1_res_getLinearization(int deviceHandle, int axis, bool* value_enabled);

static inline int ATTO_FUNCTION(res_getLinearization)(int deviceHandle, int axis, bool* value_enabled) {
    return __AMC_1_5_1_res_getLinearization(deviceHandle, axis, value_enabled);
}


/** @brief @AMC_res_setLinearization
*  Control if linearization is enabled or not.
 Please note, that this using the linearization can only be enable, if a LUT-file has been uploaded (see setLinTable)
 Please note, that active closed loop movement will be stopped when running this function to avoid unexpected movements due to the position change.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param enable           boolean ( true: enable linearization)
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_res_setLinearization(int deviceHandle, int axis, bool enable);

static inline int ATTO_FUNCTION(res_setLinearization)(int deviceHandle, int axis, bool enable) {
    return __AMC_1_5_1_res_setLinearization(deviceHandle, axis, enable);
}


/** @brief @AMC_res_getSensorStatus
*  Gets wether a valid RES position signal is present (always true for a disabled sensor and for rotators)
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_present    present true when present
*
*  @return present true when present
*/
int ATTOCUBE_API __AMC_1_5_1_res_getSensorStatus(int deviceHandle, int axis, bool* value_present);

static inline int ATTO_FUNCTION(res_getSensorStatus)(int deviceHandle, int axis, bool* value_present) {
    return __AMC_1_5_1_res_getSensorStatus(deviceHandle, axis, value_present);
}


/** @brief @AMC_res_getResFilterSetting
*  This function retrieves the current setting of the RES-signal filter.
*
*  @param deviceHandle     Handle of device
*
*  @param value_err        err error number
*  @param value_           res_filter_cfg_nbr number of the filter setting
      minimal     = 1,
      low         = 2,
      balanced    = 3,
      high        = 4,
      maximal     = 5,
*
*  @return err error number
*/
int ATTOCUBE_API __AMC_1_5_1_res_getResFilterSetting(int deviceHandle, int* value_err, int* value_);

static inline int ATTO_FUNCTION(res_getResFilterSetting)(int deviceHandle, int* value_err, int* value_) {
    return __AMC_1_5_1_res_getResFilterSetting(deviceHandle, value_err, value_);
}


/** @brief @AMC_res_setResFilterSetting
*  This function sets the RES-signal filters according to the passed config-number;
 Note, that the sensor-readout will be interrupted for a short time while this function is executed;
 it is not permitted to run this function while there is an active closed loop movement on any axis;
 If you want to keep the filter settings from previous fw-versions, please use 'balanced';
 The default setting is 'balanced'.
*
*  @param deviceHandle     Handle of device
*  @param res_filter_cfg_nbr : number of the desired filter-setting
      minimal     = 1,
      low         = 2,
      balanced    = 3,
      high        = 4,
      maximal     = 5,
*
*  @param value_err        err error-number
*
*  @return err error-number
*/
int ATTOCUBE_API __AMC_1_5_1_res_setResFilterSetting(int deviceHandle, int res_filter_cfg_nbr, int* value_err);

static inline int ATTO_FUNCTION(res_setResFilterSetting)(int deviceHandle, int res_filter_cfg_nbr, int* value_err) {
    return __AMC_1_5_1_res_setResFilterSetting(deviceHandle, res_filter_cfg_nbr, value_err);
}


/** @brief @AMC_res_setMode
*  Sets the mode of the RES position measurement
 This selects which frequency/ies are used for the lock-in measurement in AC-mode and whether or not common wires are shared
 1: (ACRES)Individual per axis: each axis is measured on a different frequency; this mode reduces noise coupling between axes, while requiring more wiring
 2: (ACRES)Shared line/MIC-Mode: each axis is measured on the same frequency, which reduces the number of required wires while more coupling noise is excpected
 3: (ACRES)Same as 1, but with overall lower frequencies. This reduces the influence on the measurement accuracy on longer cables
 4: (ACRES)Same as 2, but with overall lower frequencies. This reduces the influence on the measurement accuracy on longer cables
 5: (DCRES)Individual per axis: the RES-sensor of each axis has its own voltage supply and ground wire -> less coupling noise but more wires
 6: (DCRES)Shared: the RES-sensors of all axes share supply- and ground-wire -> more coupling noise, but less wires
 Note, that the allowed modes depend on the read-out-type of the RES-AMC. For ACRES only 1-4 and for DCRES only 5 and 6 are allowed modes.
*
*  @param deviceHandle     Handle of device
*  @param mode             1: Individual per axis, 2: Shared line mode, 3: Individual per axis (low frequency), 4: Shared line mode (low frequency), 5: Individual per axis (DCRES), 6: Shared line mode (DCRES)
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_res_setMode(int deviceHandle, int mode);

static inline int ATTO_FUNCTION(res_setMode)(int deviceHandle, int mode) {
    return __AMC_1_5_1_res_setMode(deviceHandle, mode);
}


/** @brief @AMC_res_getMode
*  Get mode of RES application, see setMode for the description of possible parameters
*
*  @param deviceHandle     Handle of device
*
*  @param mode             mode
*
*  @return mode
*/
int ATTOCUBE_API __AMC_1_5_1_res_getMode(int deviceHandle, int* mode);

static inline int ATTO_FUNCTION(res_getMode)(int deviceHandle, int* mode) {
    return __AMC_1_5_1_res_getMode(deviceHandle, mode);
}


/** @brief @AMC_rtin_getGpioMode
*  get the GPIO mode for Mic Mode feature
*
*  @param deviceHandle     Handle of device
*
*  @param value_gpio_mode  gpio_mode: 0: Standard GPIO 1: NSL-/Mic-Mode
*
*  @return gpio_mode: 0: Standard GPIO 1: NSL-/Mic-Mode
*/
int ATTOCUBE_API __AMC_1_5_1_rtin_getGpioMode(int deviceHandle, int* value_gpio_mode);

static inline int ATTO_FUNCTION(rtin_getGpioMode)(int deviceHandle, int* value_gpio_mode) {
    return __AMC_1_5_1_rtin_getGpioMode(deviceHandle, value_gpio_mode);
}


/** @brief @AMC_rtin_getNslMux
*  get the axis the NSL multiplexer is set to
*
*  @param deviceHandle     Handle of device
*
*  @param value_mux_mode   mux_mode  0: Off 1: Axis 1 2: Axis 2 3: Axis 3
*
*  @return mux_mode  0: Off 1: Axis 1 2: Axis 2 3: Axis 3
*/
int ATTOCUBE_API __AMC_1_5_1_rtin_getNslMux(int deviceHandle, int* value_mux_mode);

static inline int ATTO_FUNCTION(rtin_getNslMux)(int deviceHandle, int* value_mux_mode) {
    return __AMC_1_5_1_rtin_getNslMux(deviceHandle, value_mux_mode);
}


/** @brief @AMC_rtin_setNslMux
*  set the axis the NSL multiplexer is set to
*
*  @param deviceHandle     Handle of device
*  @param mux_mode         [0|1|2|3]
  0: Off
  1: Axis 1
  2: Axis 2
  3: Axis 3
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_rtin_setNslMux(int deviceHandle, int mux_mode);

static inline int ATTO_FUNCTION(rtin_setNslMux)(int deviceHandle, int mux_mode) {
    return __AMC_1_5_1_rtin_setNslMux(deviceHandle, mux_mode);
}


/** @brief @AMC_rtin_setGpioMode
*  set the GPIO mode for Mic Mode feature
*
*  @param deviceHandle     Handle of device
*  @param gpio_mode        [0|1]
  0: Standard GPIO
  1: NSL-/Mic-Mode
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_rtin_setGpioMode(int deviceHandle, int gpio_mode);

static inline int ATTO_FUNCTION(rtin_setGpioMode)(int deviceHandle, int gpio_mode) {
    return __AMC_1_5_1_rtin_setGpioMode(deviceHandle, gpio_mode);
}


/** @brief @AMC_rtin_getControlAQuadBInResolution
*  This function gets the AQuadB input resolution for setpoint parameter.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_resolution resolution ion nm
*
*  @return resolution ion nm
*/
int ATTOCUBE_API __AMC_1_5_1_rtin_getControlAQuadBInResolution(int deviceHandle, int axis, int* value_resolution);

static inline int ATTO_FUNCTION(rtin_getControlAQuadBInResolution)(int deviceHandle, int axis, int* value_resolution) {
    return __AMC_1_5_1_rtin_getControlAQuadBInResolution(deviceHandle, axis, value_resolution);
}


/** @brief @AMC_rtin_setControlAQuadBInResolution
*  This function sets the AQuadB input resolution for setpoint parameter.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param resolution       ion nm
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_rtin_setControlAQuadBInResolution(int deviceHandle, int axis, int resolution);

static inline int ATTO_FUNCTION(rtin_setControlAQuadBInResolution)(int deviceHandle, int axis, int resolution) {
    return __AMC_1_5_1_rtin_setControlAQuadBInResolution(deviceHandle, axis, resolution);
}


/** @brief @AMC_rtin_setRealTimeInMode
*  This function sets the real time input mode for the selected axis.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param RT_IN_MODE       0:    AquadB  (LVTTL)
 1:    AquadB  (LVDS)
 8:    Stepper (LVTTL)
 9:    Stepper (LVDS)
 10:   Trigger (LVTTL)
 11:   Trigger (LVDS)
 15:   Off
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_rtin_setRealTimeInMode(int deviceHandle, int axis, int RT_IN_MODE);

static inline int ATTO_FUNCTION(rtin_setRealTimeInMode)(int deviceHandle, int axis, int RT_IN_MODE) {
    return __AMC_1_5_1_rtin_setRealTimeInMode(deviceHandle, axis, RT_IN_MODE);
}


/** @brief @AMC_rtin_getRealTimeInMode
*  This function sets or gets the real time input mode for the selected axis.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_RT_IN_MODE RT_IN_MODE Please refer to "setRealTimeInMode" for information on possible values
*
*  @return RT_IN_MODE Please refer to "setRealTimeInMode" for information on possible values
*/
int ATTOCUBE_API __AMC_1_5_1_rtin_getRealTimeInMode(int deviceHandle, int axis, int* value_RT_IN_MODE);

static inline int ATTO_FUNCTION(rtin_getRealTimeInMode)(int deviceHandle, int axis, int* value_RT_IN_MODE) {
    return __AMC_1_5_1_rtin_getRealTimeInMode(deviceHandle, axis, value_RT_IN_MODE);
}


/** @brief @AMC_rtin_setRealTimeInChangePerPulse
*  This function sets the change per pulse for the selected axis under real time input in the closed-loop mode.
 only used in closed loop operation
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param delta            to be added to current position in nm
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_rtin_setRealTimeInChangePerPulse(int deviceHandle, int axis, int delta);

static inline int ATTO_FUNCTION(rtin_setRealTimeInChangePerPulse)(int deviceHandle, int axis, int delta) {
    return __AMC_1_5_1_rtin_setRealTimeInChangePerPulse(deviceHandle, axis, delta);
}


/** @brief @AMC_rtin_getRealTimeInChangePerPulse
*  This function gets the change per pulse for the selected axis under real time input in the closed-loop mode.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_resolution resolution to be added in current pos in nm
*
*  @return resolution to be added in current pos in nm
*/
int ATTOCUBE_API __AMC_1_5_1_rtin_getRealTimeInChangePerPulse(int deviceHandle, int axis, int* value_resolution);

static inline int ATTO_FUNCTION(rtin_getRealTimeInChangePerPulse)(int deviceHandle, int axis, int* value_resolution) {
    return __AMC_1_5_1_rtin_getRealTimeInChangePerPulse(deviceHandle, axis, value_resolution);
}


/** @brief @AMC_rtin_setRealTimeInStepsPerPulse
*  Set the change in step per pulse  of the realtime input when trigger and stepper mode is used
 only used in open loop operation
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param steps            number of steps to applied
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_rtin_setRealTimeInStepsPerPulse(int deviceHandle, int axis, int steps);

static inline int ATTO_FUNCTION(rtin_setRealTimeInStepsPerPulse)(int deviceHandle, int axis, int steps) {
    return __AMC_1_5_1_rtin_setRealTimeInStepsPerPulse(deviceHandle, axis, steps);
}


/** @brief @AMC_rtin_getRealTimeInStepsPerPulse
*  Get the change in step per pulse  of the realtime input when trigger and stepper mode is used
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_steps      steps number of steps to applied
*
*  @return steps number of steps to applied
*/
int ATTOCUBE_API __AMC_1_5_1_rtin_getRealTimeInStepsPerPulse(int deviceHandle, int axis, int* value_steps);

static inline int ATTO_FUNCTION(rtin_getRealTimeInStepsPerPulse)(int deviceHandle, int axis, int* value_steps) {
    return __AMC_1_5_1_rtin_getRealTimeInStepsPerPulse(deviceHandle, axis, value_steps);
}


/** @brief @AMC_rtin_setRealTimeInFeedbackLoopMode
*  Set if the realtime function must operate in close loop operation or open loop operation
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param mode             0: open loop, 1 : close-loop
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_rtin_setRealTimeInFeedbackLoopMode(int deviceHandle, int axis, int mode);

static inline int ATTO_FUNCTION(rtin_setRealTimeInFeedbackLoopMode)(int deviceHandle, int axis, int mode) {
    return __AMC_1_5_1_rtin_setRealTimeInFeedbackLoopMode(deviceHandle, axis, mode);
}


/** @brief @AMC_rtin_getRealTimeInFeedbackLoopMode
*  Get if the realtime function must operate in close loop operation or open loop operation
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_mode       mode 0: open loop, 1 : close-loop
*
*  @return mode 0: open loop, 1 : close-loop
*/
int ATTOCUBE_API __AMC_1_5_1_rtin_getRealTimeInFeedbackLoopMode(int deviceHandle, int axis, int* value_mode);

static inline int ATTO_FUNCTION(rtin_getRealTimeInFeedbackLoopMode)(int deviceHandle, int axis, int* value_mode) {
    return __AMC_1_5_1_rtin_getRealTimeInFeedbackLoopMode(deviceHandle, axis, value_mode);
}


/** @brief @AMC_rtin_setControlMoveGPIO
*  This function sets the status for real time input on the selected axis in closed-loop mode.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param enable           boolean true: eanble the approach , false: disable the approach
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_rtin_setControlMoveGPIO(int deviceHandle, int axis, bool enable);

static inline int ATTO_FUNCTION(rtin_setControlMoveGPIO)(int deviceHandle, int axis, bool enable) {
    return __AMC_1_5_1_rtin_setControlMoveGPIO(deviceHandle, axis, enable);
}


/** @brief @AMC_rtin_getControlMoveGPIO
*  This function gets the status for real time input on the selected axis in closed-loop mode.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_enable     enable boolean true: approach enabled , false: approach disabled
*
*  @return enable boolean true: approach enabled , false: approach disabled
*/
int ATTOCUBE_API __AMC_1_5_1_rtin_getControlMoveGPIO(int deviceHandle, int axis, bool* value_enable);

static inline int ATTO_FUNCTION(rtin_getControlMoveGPIO)(int deviceHandle, int axis, bool* value_enable) {
    return __AMC_1_5_1_rtin_getControlMoveGPIO(deviceHandle, axis, value_enable);
}


/** @brief @AMC_rtin_apply
*  Apply all realtime input function
*
*  @param deviceHandle     Handle of device
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_rtin_apply(int deviceHandle);

static inline int ATTO_FUNCTION(rtin_apply)(int deviceHandle) {
    return __AMC_1_5_1_rtin_apply(deviceHandle);
}


/** @brief @AMC_rtin_discard
*  Discard all values beting set and not yet applieds
*
*  @param deviceHandle     Handle of device
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_rtin_discard(int deviceHandle);

static inline int ATTO_FUNCTION(rtin_discard)(int deviceHandle) {
    return __AMC_1_5_1_rtin_discard(deviceHandle);
}


/** @brief @AMC_rtout_setMode
*  Set the real time output signal mode. To set either LVTTL or LVDS, please use setSignalMode-function
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param RT_OUT_MODE      0: Off, 1: AquadB, 2: Trigger
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_rtout_setMode(int deviceHandle, int axis, int RT_OUT_MODE);

static inline int ATTO_FUNCTION(rtout_setMode)(int deviceHandle, int axis, int RT_OUT_MODE) {
    return __AMC_1_5_1_rtout_setMode(deviceHandle, axis, RT_OUT_MODE);
}


/** @brief @AMC_rtout_getMode
*  Get Mode
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_RT_OUT_MODE RT_OUT_MODE For the meaning of the values, please refer to the setMode-function
*
*  @return RT_OUT_MODE For the meaning of the values, please refer to the setMode-function
*/
int ATTOCUBE_API __AMC_1_5_1_rtout_getMode(int deviceHandle, int axis, int* value_RT_OUT_MODE);

static inline int ATTO_FUNCTION(rtout_getMode)(int deviceHandle, int axis, int* value_RT_OUT_MODE) {
    return __AMC_1_5_1_rtout_getMode(deviceHandle, axis, value_RT_OUT_MODE);
}


/** @brief @AMC_rtout_setSignalMode
*  This function sets the real time output mode for the selected axis.
*
*  @param deviceHandle     Handle of device
*  @param mode             0: TTL, 1: LVDS
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_rtout_setSignalMode(int deviceHandle, int mode);

static inline int ATTO_FUNCTION(rtout_setSignalMode)(int deviceHandle, int mode) {
    return __AMC_1_5_1_rtout_setSignalMode(deviceHandle, mode);
}


/** @brief @AMC_rtout_getSignalMode
*  This function gets the real time output mode for the selected axis.
*
*  @param deviceHandle     Handle of device
*  @param tempvalue        
*
*  @param value_mode       mode 0: TTL, 1: LVDS
*
*  @return mode 0: TTL, 1: LVDS
*/
int ATTOCUBE_API __AMC_1_5_1_rtout_getSignalMode(int deviceHandle, int tempvalue, int* value_mode);

static inline int ATTO_FUNCTION(rtout_getSignalMode)(int deviceHandle, int tempvalue, int* value_mode) {
    return __AMC_1_5_1_rtout_getSignalMode(deviceHandle, tempvalue, value_mode);
}


/** @brief @AMC_rtout_setTriggerConfig
*  Control the real time output trigger config
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param higher           upper limit in nm / µdeg
*  @param lower            lower limit in nm / µdeg
*  @param epsilon          hysteresis in nm / µdeg
*  @param polarity         0: active high, 1: active low
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_rtout_setTriggerConfig(int deviceHandle, int axis, int higher, int lower, int epsilon, int polarity);

static inline int ATTO_FUNCTION(rtout_setTriggerConfig)(int deviceHandle, int axis, int higher, int lower, int epsilon, int polarity) {
    return __AMC_1_5_1_rtout_setTriggerConfig(deviceHandle, axis, higher, lower, epsilon, polarity);
}


/** @brief @AMC_rtout_getTriggerConfig
*  Get the real time output trigger config
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_higher     higher upper limit in nm / µdeg
*  @param value_lower      lower lower limit in nm / µdeg
*  @param value_epsilon    epsilon hysteresis in nm / µdeg
*  @param value_polarity   polarity 0: active high, 1: active low
*
*  @return higher upper limit in nm / µdeg
*/
int ATTOCUBE_API __AMC_1_5_1_rtout_getTriggerConfig(int deviceHandle, int axis, int* value_higher, int* value_lower, int* value_epsilon, int* value_polarity);

static inline int ATTO_FUNCTION(rtout_getTriggerConfig)(int deviceHandle, int axis, int* value_higher, int* value_lower, int* value_epsilon, int* value_polarity) {
    return __AMC_1_5_1_rtout_getTriggerConfig(deviceHandle, axis, value_higher, value_lower, value_epsilon, value_polarity);
}


/** @brief @AMC_rtout_getControlAQuadBOut
*  This function gets if of AQuadB output for position indication is enabled
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_enabled    enabled boolean
*
*  @return enabled boolean
*/
int ATTOCUBE_API __AMC_1_5_1_rtout_getControlAQuadBOut(int deviceHandle, int axis, bool* value_enabled);

static inline int ATTO_FUNCTION(rtout_getControlAQuadBOut)(int deviceHandle, int axis, bool* value_enabled) {
    return __AMC_1_5_1_rtout_getControlAQuadBOut(deviceHandle, axis, value_enabled);
}


/** @brief @AMC_rtout_getControlAQuadBOutResolution
*  This function gets the AQuadB output resolution for position indication.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_resolution resolution in nm
*
*  @return resolution in nm
*/
int ATTOCUBE_API __AMC_1_5_1_rtout_getControlAQuadBOutResolution(int deviceHandle, int axis, int* value_resolution);

static inline int ATTO_FUNCTION(rtout_getControlAQuadBOutResolution)(int deviceHandle, int axis, int* value_resolution) {
    return __AMC_1_5_1_rtout_getControlAQuadBOutResolution(deviceHandle, axis, value_resolution);
}


/** @brief @AMC_rtout_setControlAQuadBOutResolution
*  This function sets the AQuadB output resolution for position indication.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param resolution       in nm; range [1 ... 16777]
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_rtout_setControlAQuadBOutResolution(int deviceHandle, int axis, int resolution);

static inline int ATTO_FUNCTION(rtout_setControlAQuadBOutResolution)(int deviceHandle, int axis, int resolution) {
    return __AMC_1_5_1_rtout_setControlAQuadBOutResolution(deviceHandle, axis, resolution);
}


/** @brief @AMC_rtout_getControlAQuadBOutClock
*  This function gets the clock for AQuadB output.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_clock_in_ns clock_in_ns Clock in multiples of 20ns. Minimum 2 (40ns), maximum 65535 (1,310700ms)
*
*  @return clock_in_ns Clock in multiples of 20ns. Minimum 2 (40ns), maximum 65535 (1,310700ms)
*/
int ATTOCUBE_API __AMC_1_5_1_rtout_getControlAQuadBOutClock(int deviceHandle, int axis, int* value_clock_in_ns);

static inline int ATTO_FUNCTION(rtout_getControlAQuadBOutClock)(int deviceHandle, int axis, int* value_clock_in_ns) {
    return __AMC_1_5_1_rtout_getControlAQuadBOutClock(deviceHandle, axis, value_clock_in_ns);
}


/** @brief @AMC_rtout_setControlAQuadBOutClock
*  This function sets the clock for AQuadB output.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param clock            Clock in multiples of 20ns. Minimum 2 (40ns), maximum 65535 (1,310700ms)
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_rtout_setControlAQuadBOutClock(int deviceHandle, int axis, int clock);

static inline int ATTO_FUNCTION(rtout_setControlAQuadBOutClock)(int deviceHandle, int axis, int clock) {
    return __AMC_1_5_1_rtout_setControlAQuadBOutClock(deviceHandle, axis, clock);
}


/** @brief @AMC_rtout_applyAxis
*  Apply for rtout function of specific axis
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_rtout_applyAxis(int deviceHandle, int axis);

static inline int ATTO_FUNCTION(rtout_applyAxis)(int deviceHandle, int axis) {
    return __AMC_1_5_1_rtout_applyAxis(deviceHandle, axis);
}


/** @brief @AMC_rtout_apply
*  Apply for all rtout function
*
*  @param deviceHandle     Handle of device
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_rtout_apply(int deviceHandle);

static inline int ATTO_FUNCTION(rtout_apply)(int deviceHandle) {
    return __AMC_1_5_1_rtout_apply(deviceHandle);
}


/** @brief @AMC_rtout_discardAxis
*  Discard rtout value of specific axis set by the set function(not applied yet)
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_rtout_discardAxis(int deviceHandle, int axis);

static inline int ATTO_FUNCTION(rtout_discardAxis)(int deviceHandle, int axis) {
    return __AMC_1_5_1_rtout_discardAxis(deviceHandle, axis);
}


/** @brief @AMC_rtout_discardSignalMode
*  Discard value set by setSignalMode
*
*  @param deviceHandle     Handle of device
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_rtout_discardSignalMode(int deviceHandle);

static inline int ATTO_FUNCTION(rtout_discardSignalMode)(int deviceHandle) {
    return __AMC_1_5_1_rtout_discardSignalMode(deviceHandle);
}


/** @brief @AMC_rtout_discard
*  Discard all rtout value set by the set function(not applied yet)
*
*  @param deviceHandle     Handle of device
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_rtout_discard(int deviceHandle);

static inline int ATTO_FUNCTION(rtout_discard)(int deviceHandle) {
    return __AMC_1_5_1_rtout_discard(deviceHandle);
}


/** @brief @AMC_amcids_getAutoStop
*  Reads the current setting of auto_stop in case of an error raised by the IDS.
*   If True, the closedloop movement is stopped automatically.
*
*  @param deviceHandle     Handle of device
*  @param axis             Axis [0|1|2] on which the autostop is read
*
*  @param auto_stop        True if closedloop move shall stop automatically on error reported by IDS
*
*  @return True if closedloop move shall stop automatically on error reported by IDS
*/
int ATTOCUBE_API __AMC_1_5_1_amcids_getAutoStop(int deviceHandle, int axis, bool* auto_stop);

static inline int ATTO_FUNCTION(amcids_getAutoStop)(int deviceHandle, int axis, bool* auto_stop) {
    return __AMC_1_5_1_amcids_getAutoStop(deviceHandle, axis, auto_stop);
}


/** @brief @AMC_amcids_getError
*  Reads the statuses of the RT- and ethernet-connection.
*   All return parameters follow the following logic:
*   0: no error occured since last reset
*   1: error is occurring at the moment
*   2: error occured in the past, but not at the moment
*   3: error is occurring at the moment and latched
*
*  @param deviceHandle     Handle of device
*
*  @param itf_ids_error_all_axes indicates an error reported by the IDS on axis 1, 2 or 3 (see above for value-explanation)
*  @param itf_link_error_all_axes indicates a link error detected on axis 1, 2 or 3  (see above for value-explanation)
*  @param itf_ids_error_ax_1 indicates an error reported by the IDS on axis 1 (e.g. beam interrupt). (see above for value-explanation)
*  @param itf_ids_error_ax_2 indicates an error reported by the IDS on axis 2 (e.g. beam interrupt). (see above for value-explanation)
*  @param itf_ids_error_ax_3 indicates an error reported by the IDS on axis 3 (e.g. beam interrupt). (see above for value-explanation)
*  @param itf_link_error_ax_1 indicates a link error detected on axis 1 (e.g. wiring/cable problem). (see above for value-explanation)
*  @param itf_link_error_ax_2 indicates a link error detected on axis 2 (e.g. wiring/cable problem). (see above for value-explanation)
*  @param itf_link_error_ax_3 indicates a link error detected on axis 3 (e.g. wiring/cable problem). (see above for value-explanation)
*  @param eth_con_error    indicates an ethernet connection error between AMC and IDS (see above for value-explanation)
*
*  @return indicates an error reported by the IDS on axis 1, 2 or 3 (see above for value-explanation)
*/
int ATTOCUBE_API __AMC_1_5_1_amcids_getError(int deviceHandle, int* itf_ids_error_all_axes, int* itf_link_error_all_axes, int* itf_ids_error_ax_1, int* itf_ids_error_ax_2, int* itf_ids_error_ax_3, int* itf_link_error_ax_1, int* itf_link_error_ax_2, int* itf_link_error_ax_3, int* eth_con_error);

static inline int ATTO_FUNCTION(amcids_getError)(int deviceHandle, int* itf_ids_error_all_axes, int* itf_link_error_all_axes, int* itf_ids_error_ax_1, int* itf_ids_error_ax_2, int* itf_ids_error_ax_3, int* itf_link_error_ax_1, int* itf_link_error_ax_2, int* itf_link_error_ax_3, int* eth_con_error) {
    return __AMC_1_5_1_amcids_getError(deviceHandle, itf_ids_error_all_axes, itf_link_error_all_axes, itf_ids_error_ax_1, itf_ids_error_ax_2, itf_ids_error_ax_3, itf_link_error_ax_1, itf_link_error_ax_2, itf_link_error_ax_3, eth_con_error);
}


/** @brief @AMC_amcids_getLowerSoftLimit
*  Gets the lower boundary of the soft limit protection.
*   This protection is needed if the IDS working range is smaller than the positioners travel range.
*   It is no hard limit, so, it is possible to overshoot it!
*
*  @param deviceHandle     Handle of device
*  @param axis             Axis [0|1|2] of the AMC to get the soft limit status from
*
*  @param limit            Lower boundary in micrometers
*
*  @return Lower boundary in micrometers
*/
int ATTOCUBE_API __AMC_1_5_1_amcids_getLowerSoftLimit(int deviceHandle, int axis, double* limit);

static inline int ATTO_FUNCTION(amcids_getLowerSoftLimit)(int deviceHandle, int axis, double* limit) {
    return __AMC_1_5_1_amcids_getLowerSoftLimit(deviceHandle, axis, limit);
}


/** @brief @AMC_amcids_getSoftLimitEnabled
*  Gets whether the soft limit protection is enabled.
*   This protection is needed if the IDS working range is smaller than the positioners travel range.
*   It is no hard limit, so, it is possible to overshoot it!
*
*  @param deviceHandle     Handle of device
*  @param axis             Axis [0|1|2] of the AMC to get the soft limit status from
*
*  @param enabled          True, if the soft limit should be enabled on this axis
*
*  @return True, if the soft limit should be enabled on this axis
*/
int ATTOCUBE_API __AMC_1_5_1_amcids_getSoftLimitEnabled(int deviceHandle, int axis, bool* enabled);

static inline int ATTO_FUNCTION(amcids_getSoftLimitEnabled)(int deviceHandle, int axis, bool* enabled) {
    return __AMC_1_5_1_amcids_getSoftLimitEnabled(deviceHandle, axis, enabled);
}


/** @brief @AMC_amcids_getSoftLimitRange
*  Reads the lower and upper boundary of the soft limit protection.
*
*  @param deviceHandle     Handle of device
*  @param axis             Axis of the AMC to get the soft limit status from
*
*  @param lower_limit      Lower boundary in micrometers
*  @param upper_limit      Upper boundary in micrometers
*
*  @return Lower boundary in micrometers
*/
int ATTOCUBE_API __AMC_1_5_1_amcids_getSoftLimitRange(int deviceHandle, int axis, int* lower_limit, int* upper_limit);

static inline int ATTO_FUNCTION(amcids_getSoftLimitRange)(int deviceHandle, int axis, int* lower_limit, int* upper_limit) {
    return __AMC_1_5_1_amcids_getSoftLimitRange(deviceHandle, axis, lower_limit, upper_limit);
}


/** @brief @AMC_amcids_getSoftLimitReached
*  Gets whether the current position is out of the soft limit boundaries.
*   This protection is needed if the IDS working range is smaller than the positioners travel range.
*   It is no hard limit, so, it is possible to overshoot it!
*
*  @param deviceHandle     Handle of device
*  @param axis             Axis [0|1|2] of the AMC to get the soft limit status from
*
*  @param enabled          True, if the position is not within the boundaries
*
*  @return True, if the position is not within the boundaries
*/
int ATTOCUBE_API __AMC_1_5_1_amcids_getSoftLimitReached(int deviceHandle, int axis, bool* enabled);

static inline int ATTO_FUNCTION(amcids_getSoftLimitReached)(int deviceHandle, int axis, bool* enabled) {
    return __AMC_1_5_1_amcids_getSoftLimitReached(deviceHandle, axis, enabled);
}


/** @brief @AMC_amcids_getUpperSoftLimit
*  Gets the upper boundary of the soft limit protection.
*   This protection is needed if the IDS working range is smaller than the positioners travel range.
*   It is no hard limit, so, it is possible to overshoot it!
*
*  @param deviceHandle     Handle of device
*  @param axis             Axis [0|1|2] of the AMC to get the soft limit status from
*
*  @param limit            Upper boundary in micrometers
*
*  @return Upper boundary in micrometers
*/
int ATTOCUBE_API __AMC_1_5_1_amcids_getUpperSoftLimit(int deviceHandle, int axis, double* limit);

static inline int ATTO_FUNCTION(amcids_getUpperSoftLimit)(int deviceHandle, int axis, double* limit) {
    return __AMC_1_5_1_amcids_getUpperSoftLimit(deviceHandle, axis, limit);
}


/** @brief @AMC_amcids_resetError
*  Resets the latched error information of the RT- and ethernet-errors (see getError-method)
*   The axis-parameter only applies to the RT-errors and ids-errors - the ethernet-error is not reset axis-specifically
*
*  @param deviceHandle     Handle of device
*  @param axis             The index of the axis [0|1|2] whose RT- and IDS-error information should be reset.
Note, that the IDS error is reset for all three axes, if an error is detected on the given axis.
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_amcids_resetError(int deviceHandle, int axis);

static inline int ATTO_FUNCTION(amcids_resetError)(int deviceHandle, int axis) {
    return __AMC_1_5_1_amcids_resetError(deviceHandle, axis);
}


/** @brief @AMC_amcids_resetIdsAxis
*  Resets the position value to zero of a specific measurement axis.
*   Use this for positioners with an IDS as sensor.
*   This method does not work for NUM and RES sensors. Use com.attocube.amc.control.resetAxis instead.
*
*  @param deviceHandle     Handle of device
*  @param axis             Axis [0|1|2] of the IDS to reset the position
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_amcids_resetIdsAxis(int deviceHandle, int axis);

static inline int ATTO_FUNCTION(amcids_resetIdsAxis)(int deviceHandle, int axis) {
    return __AMC_1_5_1_amcids_resetIdsAxis(deviceHandle, axis);
}


/** @brief @AMC_amcids_setAutoStop
*  When auto_stop is set to 'True', the AMC automatically stops cl-movement in case of an error indicated by the IDS (e.g. beam-interrupt)
*   Note, that the AMC always stops closed-loop-movement automatically, if the transferred position is invalid
*   (e.g. if the sensor-cable was disconnected)
*   Note, that in case of active 'stop at end of travel'-setting (check function setControlEotOutputDeactive),
*   the movement would stop despite setting auto_stop to 'False' for an error reported by the IDS, because the AMC interprets the invalid
*   position-value as "end of travel".
*   With getError the states of the errors can be retrieved.
*
*  @param deviceHandle     Handle of device
*  @param axis             indicates the device axis [0|1|2] on which the auto-stop shall be applied
*  @param auto_stop        if 'True' the closedloop move will stop, if the IDS reports errors on this axis
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_amcids_setAutoStop(int deviceHandle, int axis, bool auto_stop);

static inline int ATTO_FUNCTION(amcids_setAutoStop)(int deviceHandle, int axis, bool auto_stop) {
    return __AMC_1_5_1_amcids_setAutoStop(deviceHandle, axis, auto_stop);
}


/** @brief @AMC_amcids_setLowerSoftLimit
*  Sets the lower boundary of the soft limit protection.
*   This protection is needed if the IDS working range is smaller than the positioners travel range.
*   It is no hard limit, so, it is possible to overshoot it!
*
*  @param deviceHandle     Handle of device
*  @param axis             Axis [0|1|2] of the AMC where the soft limit should be changed
*  @param limit            Lower boundary in micrometers
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_amcids_setLowerSoftLimit(int deviceHandle, int axis, double limit);

static inline int ATTO_FUNCTION(amcids_setLowerSoftLimit)(int deviceHandle, int axis, double limit) {
    return __AMC_1_5_1_amcids_setLowerSoftLimit(deviceHandle, axis, limit);
}


/** @brief @AMC_amcids_setSoftLimitEnabled
*  Enables/disables the soft limit protection.
*   This protection is needed if the IDS working range is smaller than the positioners travel range.
*   It is no hard limit, so, it is possible to overshoot it!
*
*  @param deviceHandle     Handle of device
*  @param axis             Axis [0|1|2] of the AMC where the soft limit should be changed
*  @param enabled          True, if the soft limit should be enabled on this axis
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_amcids_setSoftLimitEnabled(int deviceHandle, int axis, bool enabled);

static inline int ATTO_FUNCTION(amcids_setSoftLimitEnabled)(int deviceHandle, int axis, bool enabled) {
    return __AMC_1_5_1_amcids_setSoftLimitEnabled(deviceHandle, axis, enabled);
}


/** @brief @AMC_amcids_setSoftLimitRange
*  Sets the lower and upper boundry of the soft limit protection in micrometers.
*   This protection is needed if the IDS working range is smaller than the positioners travel range.
*   It is no hard limit, so, it is possible to overshoot it!
*   The given values are interpreted as absoulte positions (reference position + displacement).
*
*  @param deviceHandle     Handle of device
*  @param axis             Axis [0|1|2] of the AMC where the soft limits should be changed
*  @param lowerLimit       lower boundary in micrometers as absolute position; has to be lower than upperLimit
*  @param upperLimit       upper boundary in micrometers as absolute position; has to be higher than lowerLimit
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_amcids_setSoftLimitRange(int deviceHandle, int axis, int lowerLimit, int upperLimit);

static inline int ATTO_FUNCTION(amcids_setSoftLimitRange)(int deviceHandle, int axis, int lowerLimit, int upperLimit) {
    return __AMC_1_5_1_amcids_setSoftLimitRange(deviceHandle, axis, lowerLimit, upperLimit);
}


/** @brief @AMC_amcids_setUpperSoftLimit
*  Sets the upper boundary of the soft limit protection.
*   This protection is needed if the IDS working range is smaller than the positioners travel range.
*   It is no hard limit, so, it is possible to overshoot it!
*
*  @param deviceHandle     Handle of device
*  @param axis             Axis [0|1|2] of the AMC where the soft limit should be changed
*  @param limit            Upper boundary in micrometers
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_amcids_setUpperSoftLimit(int deviceHandle, int axis, double limit);

static inline int ATTO_FUNCTION(amcids_setUpperSoftLimit)(int deviceHandle, int axis, double limit) {
    return __AMC_1_5_1_amcids_setUpperSoftLimit(deviceHandle, axis, limit);
}


/** @brief @AMC_grantAccess
*  Grants access to a locked device by checking against the password.
*
*  @param deviceHandle     Handle of device
*  @param password         current password string
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_access_grantAccess(int deviceHandle, const char* password);

static inline int ATTO_FUNCTION(grantAccess)(int deviceHandle, const char* password) {
    return __AMC_1_5_1_access_grantAccess(deviceHandle, password);
}


/** @brief @AMC_lock
*  Locks the device with a given password. Afterwards, the device functions are only accessible with this password. The computer IP address, which locks the device, is automatically added to the device and doesn't need the password for functions access.
*
*  @param deviceHandle     Handle of device
*  @param password         set password string
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_access_lock(int deviceHandle, const char* password);

static inline int ATTO_FUNCTION(lock)(int deviceHandle, const char* password) {
    return __AMC_1_5_1_access_lock(deviceHandle, password);
}


/** @brief @AMC_unlock
*  Unlocks the device. Afterwards, the device functions are accessible without any password. For grant access without unlocking the device, please use the grantAccess function.
*
*  @param deviceHandle     Handle of device
*  @param password         current password string
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API __AMC_1_5_1_access_unlock(int deviceHandle, const char* password);

static inline int ATTO_FUNCTION(unlock)(int deviceHandle, const char* password) {
    return __AMC_1_5_1_access_unlock(deviceHandle, password);
}


/** @brief @AMC_getLockStatus
*  Gets the lock status of the device and if the current client is authorized to use the device.
*
*  @param deviceHandle     Handle of device
*
*  @param value_error      error code, if there was an error, otherwise 0 for ok
*  @param value_locked     locked true = locked; false = unlocked
*  @param value_authorized authorized true if the client is authorized, else false
*
*  @return error code, if there was an error, otherwise 0 for ok
*/
int ATTOCUBE_API __AMC_1_5_1_access_getLockStatus(int deviceHandle, int* value_error, bool* value_locked, bool* value_authorized);

static inline int ATTO_FUNCTION(getLockStatus)(int deviceHandle, int* value_error, bool* value_locked, bool* value_authorized) {
    return __AMC_1_5_1_access_getLockStatus(deviceHandle, value_error, value_locked, value_authorized);
}


#ifdef __cplusplus
}
#endif
#undef ATTO_PREFIX
#endif // __GENERATEDAPI_H_AMC_1_5_1__